========================
Guzzle Sphinx Theme Demo
========================

.. toctree::
    :hidden:

    page-1
    table-with-code
    pymethod


Check this out
--------------

1. Foo
2. Bar
3. Baz


Another list
------------

* `lorem ipsum dolor <https://github.com/guzzle/guzzle_sphinx_theme>`_
* dolor lorem ipsum
* lorem ipsum dolor
* dolor lorem ipsum


Some definitions
----------------

Donec sodales
    velit ac sagittis fermentum, metus ante pharetra ex, ac eleifend
    erat ligula in lacus. Donec tincidunt urna est, non mollis turpis lacinia

sit amet
    Duis ac facilisis libero, ut interdum nibh. Sed rutrum dapibus pharetra.

Ut ac luctus nisi
    vitae volutpat arcu. Vivamus venenatis eu nibh ut consectetur. Cras
    tincidunt dui nisi, et facilisis eros feugiat nec.
