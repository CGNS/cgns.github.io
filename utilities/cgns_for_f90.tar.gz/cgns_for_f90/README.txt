Generate a fully fortran 90 module.

By using this module you can avoid the preprocessor define
in the fortran 90 code.

USAGE:

1. set INCDIR to point correctly in Makefile
2. Type:  make
3. Be sure to have copy of cgnslib_f.h locally
4. Type:  ./cgns_parser_f90.x -i cgnslib_f.h  -o cgnslib.f90


Author: Mirco Valentini  (mirco.valentini@polimi.it)
