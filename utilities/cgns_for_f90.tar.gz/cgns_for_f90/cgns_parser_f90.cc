#include <stdio.h>
#include <string.h>
#include <cstdlib>
#include <cerrno>
#include <cfloat>
#include <iostream>
#include <stdio.h>

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#include <sstream>
#include <fstream>
#include <iostream>
#include <ostream>

#include <map>
#include <vector>
#include <string>
#include <algorithm>

#include "cgns_io.h"

#include "cgnstypes_f.h"

# define A( X ) B( X )
# define B( X ) #X

using namespace std;

typedef map<string, string> symbol_table;

std::string trim(const std::string& str,
                 const std::string& whitespace = " \t")
{
    const int strBegin = str.find_first_not_of(whitespace);
    if (strBegin == std::string::npos)
        return ""; 

    const int strEnd = str.find_last_not_of(whitespace);
    const int strRange = strEnd - strBegin + 1;

    return str.substr(strBegin, strRange);
}

bool split_comma( string& str, string& str1 )
{
  int p = str.find( "," );
  int s = str.size();
  if( p>0 && p<s )
  {
    str1 = str.substr( p+1, s );
    str = str.substr( 0, p );
    return true;
  }
  return false;
};

bool split_space( string& str, string& str1 )
{
  int p = str.find( " " );
  int s = str.size();
  if( p>0 && p<s )
  {
    str1 = str.substr( p+1, s );
    str = str.substr( 0, p );
    return true;
  }
  return false;
};

bool split_equal( string& str, string& str1 )
{
  int p = str.find( "=" );
  int s = str.size();
  if( p>0 && p<s )
  {
    str1 = str.substr( p+1, s );
    str = str.substr( 0, p );
    return true;
  }
  return false;
};

bool split_bracket( string& str, string& str1 )
{
  int p1 = str.find( "(" );
  int p2 = str.find( ")" );
  int s = str.size();    
  if( (p1>0 && p1<s) &&
      (p2>p1 && p2<=s-1) )
  {
    str1 = str.substr( p1+1, p2-p1-1 );
    str = str.substr( 0, p1 );
    return true;
  }
  return false;
};


bool read_parameter( std::ifstream& input, std::string& line, std::ofstream& output )
{

  bool success;
  std::string tmp;
  std::string name;
  std::string value;

  success = split_bracket( line, tmp );

  if ( success == 0 )
  {
    cout << "ERROR!!! 0" << endl;
    return false;
  }

  success = split_equal( tmp, value );

  if ( success == 0 )
  {
    cout << "ERROR!!! 1" << endl;
    return false;
  }

  name = trim( tmp );
  tmp = value;
  value = trim( tmp );

  output << "  INTEGER(KIND=CGSIZE_T), PARAMETER :: " << name << "=" << value << endl;

  return true;

}

bool read_character( std::ifstream& input, std::string& line, std::ofstream& output, symbol_table& mSymbolTable )
{

  bool success;
  std::string name;
  std::string value;

  line = trim( line );

  success = split_bracket( line, value );

  if ( success == 0 )
  {
    cout << "ERROR!!! 0" << endl;
    return false;
  }

  success = split_space( line, name );

  if ( success == 0 )
  {
    cout << "ERROR!!! 1" << endl;
    return false;
  }

  name = trim( name );
  value = trim( value );

  pair<string, string > tmp;
  tmp.first = name;
  tmp.second = value;
  mSymbolTable.insert( tmp );

  return true;

}

void get_full_line( std::ifstream& input, std::string& line )
{

  string newline;
  int found = 1;

  line = trim( line );
  if ( line.substr( line.length()-1, line.length()-1 ) == "&" )
  {
    line = trim( line.substr(0,line.length()-1) );

    while (1)
    {
  
      getline( input, newline );

      if ( input.bad() == 1 )
      {
        cout << "I/O ERROR!!!!!" << endl;
        break;
      }

      if ( input.eof() == 0 )
      {

        newline = trim( newline);
        if ( newline.substr( 0, 1 ) == "&" )
        {
          newline = trim( newline.substr(1,newline.length()) );
        }

        if ( newline.substr( newline.length()-1, newline.length()-1 ) == "&" )
        {
          newline = trim( newline.substr(0,newline.length()-1) );
        }
        else
        {
          found=0;
        }

        if ( found == 1 )
        {
          line.append( newline );
          newline="";
        }
        else
        {
          line.append( newline );
          newline="";
          break;
        }
      }
      else
      {
        break;
      }
    }
  }

}


bool read_data( std::ifstream& input, std::string& line, std::ofstream& output, symbol_table& mSymbolTable )
{

  bool success;
  std::string tmp;
  std::string sep;
  std::string sep1;
  std::string name;
  std::vector<std::string> value;

  get_full_line( input, line );

  success = split_space( line, tmp );

  line = trim( tmp );

  success = split_space( line, tmp );

  name = trim(line);
  line = trim(tmp);

  if ( line.substr( 0, 1 ) == "/" )
  {
    line = trim( line.substr(1,line.length()) );
  }
   if ( line.substr( line.length()-1, line.length()-1 ) == "/" )
  {
    line = trim( line.substr(0,line.length()-1) );
  }

  while (1)
  {

    success = split_comma( line, tmp );

    if ( success == 0) break;

    value.push_back( trim(line.substr(1,line.length()-2)) );
    line = trim(tmp);

  }
  tmp = trim(tmp);
  value.push_back( trim(tmp.substr(1,tmp.length()-2)) );

  symbol_table::iterator itv;
  itv = mSymbolTable.find( name );
  if ( itv != mSymbolTable.end() )
  {
    tmp = "  CHARACTER(LEN=32), DIMENSION("; 
    tmp.append( itv->second ); 
    tmp.append( "), PARAMETER :: " );
    tmp.append( name );
    tmp.append( "= (/ &" );

    sep.insert( 0, 34, ' ' );

    output << tmp << endl;


    for ( int i=0; i<value.size()-1; i++ )
    {
      int l = 32 - value[i].length();
      sep1 = "";
      sep1.insert( 0, l, ' ' );
      output << sep << "'" << value[i] << sep1 << "', &" << endl;
    }
    int l = 32 - value[value.size()-1].length();
    sep1 = "";
    sep1.insert( 0, l, ' ' );
    output << sep << "'" << value[value.size()-1] << sep1 << "' /)" << endl;

  }
  else
  {
    cout << "Value not found" << endl;
  }

  return true;

}


void cgnslib( std::ofstream& output, string ifname )
{
  bool found;
  std::ifstream input( ifname.c_str() );
  std::string line;

  int head = 1;

  symbol_table mSymbolTable;

  getline( input, line );

  while (1)
  {

    if ( input.bad() == 1 )
    {
      cout << "I/O ERROR!!!!!" << endl;
      break;
    }

    if ( input.eof() == 0 )
    {

      std::string tline = trim( line );
      line = trim( line );
      if ( line.substr( 0, 1 ) == "c" )
      {
        line = trim( line.substr(1,line.length()) );
        output << "!" << line << endl;
        getline( input, line );
      }
      else if ( line.substr( 0, 1 ) == "!" )
      {
        output << line << endl;
        getline( input, line );
      }
      else
      {
        break;
      }

    }

  }

  output << "MODULE cgnslib" << endl;
  output << endl;
  output << "  USE :: cgns_types, ONLY: CGSIZE_T" << endl;
  output << endl;
  output << "IMPLICIT NONE" << endl;
  output << endl;
  output << "  PUBLIC" << endl;
  output << endl;

  while (1)
  {

    if ( input.bad() == 1 )
    {
      cout << "I/O ERROR!!!!!" << endl;
      break;
    }

    if ( input.eof() == 0 )
    {

      std::string tline = trim( line );
      if ( tline.length() > 9 )
      {

        std::string card = tline.substr(0,4);
        found = false;

        if ( card.compare( "inte" ) == 0 )
        {
          found = true;
          getline( input, line );
          continue;
        }

        if ( card.compare( "para" ) == 0 )
        {
          found = true;
          bool success = read_parameter( input, line, output );
          if ( success == 0 ) 
          {
            cout << "ERROR" << endl;
            break;
          }
          getline( input, line );
          continue;
        }

        if ( card.compare( "char" ) == 0 )
        {
          bool success = read_character( input, line, output, mSymbolTable );
          if ( success == 0 ) 
          {
            cout << "ERROR" << endl;
            break;
          }  
          getline( input, line );
          found = true;
        }

        if ( card.compare( "data" ) == 0 )
        {
          found = true;
          bool success = read_data( input, line, output, mSymbolTable );
          if ( success == 0 ) 
          {
            cout << "ERROR" << endl;
            break;
          } 
          getline( input, line );
          continue;
        }

        if ( found == false )
        {
          line = trim( line );
          if ( line.substr( 0, 1 ) == "c" )
          {
            line = trim( line.substr(1,line.length()) );
            output << "  " << "!" << line << endl;
          }
          else if ( line.substr( 0, 1 ) == "!" )
          {
            output << "  " << line << endl;
          }
          getline( input, line );
          continue;
        }
      }
      else
      {
          line = trim( line );
          if ( line.substr( 0, 1 ) == "c" )
          {
            line = trim( line.substr(1,line.length()) );
            output << "  " << "!" << line << endl;
          }
          else if ( line.substr( 0, 1 ) == "!" )
          {
            output << "  " << line << endl;
          }
          else
          {
            output << line << endl;
          }
          getline( input, line );
          continue;
      }
    }
    else
    {
      break;
    }

  }

  output << endl << "  PRIVATE :: CGSIZE_T" << endl;
  output << endl << "END MODULE cgnslib" << endl;

  input.close();

}


int extract ( const char* str_ )
{

  int i, r;
  const char* sep="*";

  for ( i=1; i<strlen(str_ ); i++)
  {
    if ( str_[i-1] == sep[0] )
    {
      r = atoi( &str_[i] );
    }

  }

  return r;

}

void cgns_types( std::ofstream& output )
{

  const char * cgst=A( CGSIZE_T );
  const char * cglng=A( CGLONG_T );
  const char * cgid=A( CGID_T );

  output << "MODULE cgns_types" << endl << endl;

  output << "IMPLICIT NONE" << endl << endl;
  output << "  PUBLIC" << endl << endl;
  output << "  INTEGER, PARAMETER :: CG_BUILD_64BIT=" << CG_BUILD_64BIT << endl << endl;

  output << "  INTEGER, PARAMETER :: CGSIZE_T=" << extract(cgst) << endl;
  output << "  INTEGER, PARAMETER :: CGLONG_T=" << extract(cglng) << endl;
  output << "  INTEGER, PARAMETER :: CGID_T=" << extract(cgid) << endl << endl;

  output << "END MODULE" << endl;

}


void cgns_io( std::ofstream& output )
{

  output << "MODULE cgio" << endl << endl;

  output << "  USE :: cgns_types, ONLY: CGSIZE_T"  << endl<< endl;

  output << "IMPLICIT NONE" << endl << endl;

  output << "  PUBLIC" << endl << endl;

  output << "  INTEGER(KIND=CGSIZE_T), PARAMETER :: CGIO_MODE_READ=" << CGIO_MODE_READ << endl;
  output << "  INTEGER(KIND=CGSIZE_T), PARAMETER :: CGIO_MODE_WRITE=" << CGIO_MODE_WRITE << endl;
  output << "  INTEGER(KIND=CGSIZE_T), PARAMETER :: CGIO_MODE_MODIFY=" << CGIO_MODE_MODIFY << endl << endl;

  output << "  INTEGER(KIND=CGSIZE_T), PARAMETER :: CGIO_FILE_NONE=" << CGIO_FILE_NONE << endl;
  output << "  INTEGER(KIND=CGSIZE_T), PARAMETER :: CGIO_FILE_ADF=" << CGIO_FILE_ADF << endl;
  output << "  INTEGER(KIND=CGSIZE_T), PARAMETER :: CGIO_FILE_HDF5=" << CGIO_FILE_HDF5 << endl;
  output << "  INTEGER(KIND=CGSIZE_T), PARAMETER :: CGIO_FILE_ADF2=" << CGIO_FILE_ADF2 << endl;
  output << "  INTEGER(KIND=CGSIZE_T), PARAMETER :: CGIO_FILE_PHDF5=" << CGIO_FILE_PHDF5 << endl << endl;

  output << "  INTEGER(KIND=CGSIZE_T), PARAMETER :: CGIO_MAX_DATATYPE_LENGTH=" << CGIO_MAX_DATATYPE_LENGTH << endl;
  output << "  INTEGER(KIND=CGSIZE_T), PARAMETER :: CGIO_MAX_DIMENSIONS=" << CGIO_MAX_DIMENSIONS << endl;
  output << "  INTEGER(KIND=CGSIZE_T), PARAMETER :: CGIO_MAX_NAME_LENGTH=" << CGIO_MAX_NAME_LENGTH << endl;
  output << "  INTEGER(KIND=CGSIZE_T), PARAMETER :: CGIO_MAX_LABEL_LENGTH=" << CGIO_MAX_LABEL_LENGTH << endl;
  output << "  INTEGER(KIND=CGSIZE_T), PARAMETER :: CGIO_MAX_VERSION_LENGTH=" << CGIO_MAX_VERSION_LENGTH << endl;
  output << "  INTEGER(KIND=CGSIZE_T), PARAMETER :: CGIO_MAX_DATE_LENGTH=" << CGIO_MAX_DATE_LENGTH << endl;
  output << "  INTEGER(KIND=CGSIZE_T), PARAMETER :: CGIO_MAX_ERROR_LENGTH=" << CGIO_MAX_ERROR_LENGTH << endl;
  output << "  INTEGER(KIND=CGSIZE_T), PARAMETER :: CGIO_MAX_LINK_DEPTH=" << CGIO_MAX_LINK_DEPTH << endl;
  output << "  INTEGER(KIND=CGSIZE_T), PARAMETER :: CGIO_MAX_FILE_LENGTH=" << CGIO_MAX_FILE_LENGTH << endl;
  output << "  INTEGER(KIND=CGSIZE_T), PARAMETER :: CGIO_MAX_LINK_LENGTH=" << CGIO_MAX_LINK_LENGTH << endl << endl;

  output << "  INTEGER(KIND=CGSIZE_T), PARAMETER :: CGIO_ERR_NONE=" << CGIO_ERR_NONE << endl;
  output << "  INTEGER(KIND=CGSIZE_T), PARAMETER :: CGIO_ERR_BAD_CGIO=" << CGIO_ERR_BAD_CGIO << endl;
  output << "  INTEGER(KIND=CGSIZE_T), PARAMETER :: CGIO_ERR_MALLOC=" << CGIO_ERR_MALLOC << endl;
  output << "  INTEGER(KIND=CGSIZE_T), PARAMETER :: CGIO_ERR_FILE_MODE=" << CGIO_ERR_FILE_MODE << endl;
  output << "  INTEGER(KIND=CGSIZE_T), PARAMETER :: CGIO_ERR_FILE_TYPE=" << CGIO_ERR_FILE_TYPE << endl;
  output << "  INTEGER(KIND=CGSIZE_T), PARAMETER :: CGIO_ERR_NULL_FILE=" << CGIO_ERR_NULL_FILE << endl;
  output << "  INTEGER(KIND=CGSIZE_T), PARAMETER :: CGIO_ERR_TOO_SMALL=" << CGIO_ERR_TOO_SMALL << endl;
  output << "  INTEGER(KIND=CGSIZE_T), PARAMETER :: CGIO_ERR_NOT_FOUND=" << CGIO_ERR_NOT_FOUND << endl;
  output << "  INTEGER(KIND=CGSIZE_T), PARAMETER :: CGIO_ERR_NULL_PATH=" << CGIO_ERR_NULL_PATH << endl;
  output << "  INTEGER(KIND=CGSIZE_T), PARAMETER :: CGIO_ERR_NO_MATCH=" << CGIO_ERR_NO_MATCH << endl;
  output << "  INTEGER(KIND=CGSIZE_T), PARAMETER :: CGIO_ERR_FILE_OPEN=" << CGIO_ERR_FILE_OPEN << endl;
  output << "  INTEGER(KIND=CGSIZE_T), PARAMETER :: CGIO_ERR_READ_ONLY=" << CGIO_ERR_READ_ONLY << endl;
  output << "  INTEGER(KIND=CGSIZE_T), PARAMETER :: CGIO_ERR_NULL_STRING=" << CGIO_ERR_NULL_STRING << endl;
  output << "  INTEGER(KIND=CGSIZE_T), PARAMETER :: CGIO_ERR_BAD_OPTION=" << CGIO_ERR_BAD_OPTION << endl;
  output << "  INTEGER(KIND=CGSIZE_T), PARAMETER :: CGIO_ERR_FILE_RENAME=" << CGIO_ERR_FILE_RENAME << endl;
  output << "  INTEGER(KIND=CGSIZE_T), PARAMETER :: CGIO_ERR_TOO_MANY=" << CGIO_ERR_TOO_MANY << endl;
  output << "  INTEGER(KIND=CGSIZE_T), PARAMETER :: CGIO_ERR_DIMENSIONS=" << CGIO_ERR_DIMENSIONS << endl;
  output << "  INTEGER(KIND=CGSIZE_T), PARAMETER :: CGIO_ERR_BAD_TYPE=" << CGIO_ERR_BAD_TYPE << endl;
  output << "  INTEGER(KIND=CGSIZE_T), PARAMETER :: CGIO_ERR_NOT_HDF5=" << CGIO_ERR_NOT_HDF5 << endl << endl;
  output << endl << "  PRIVATE :: CGSIZE_T" << endl << endl;
  output << "END MODULE cgio" << endl;

}

int main( int argc, char* argv[] )
{

  string ifname;
  string ofname;

  if ( argc != 5 ) 
  {
    std::cout << " Wrong input arguments, please try again." << std::endl;
    return 1;
  }

  int i = 0;
  do { 
      if ( i < argc-2 ) 
      {
        i++;
      } 
      else 
      {
        break;
      }

      if (i + 1 != argc) 
          if ( strcmp( argv[i], "-i") == 0) {
              i++;
              ifname.assign( argv[i] );
          } else if (strcmp( argv[i], "-o" ) == 0 ) {
              i++;
              ofname.assign( argv[i] );
          } else {
              std::cout << i << " Not enough or invalid arguments, please try again.\n";
              return 1;
      }

  } while(1);

  std::ofstream output( ofname.c_str() );

  cgns_types( output );

  output << endl << endl << endl;

  cgns_io( output );

  output << endl << endl << endl;

  cgnslib( output, ifname );

  output.close();

  return 0;

}
