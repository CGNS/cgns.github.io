/* this is adfedit.c */

#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include "ADF.h"

#ifndef FALSE
#define FALSE    0
#endif
#ifndef TRUE
#define TRUE     1
#endif

#define MAXDEPTH 1000 /* max depth of tree printable */

typedef struct {
    char *name;
    double id;
    int nlevelsmax;
    } Dir_t;

/*wrj:  Probably want to make cwd  Dir_t **cwd and external.
        Also then have an external int nod for the number of
        open databases */


typedef struct {
  int report_labels;
  int report_datatype;
  } Flags_t;



char status[32], format[32];
static double root_ID;
static int fileopen;

extern void err_exit(char *name, int error_return);

extern void main_screen();
extern void translator_screen();
extern void browser_screen();
extern void tools_screen();

extern void main_help(char *input);
extern void translator_help(char *input);
extern void browser_help(char *input);
extern void tools_help(char *input);


/*
static void build_test_path(char *name,char *input, char *tp);
static void do_a_cd(Dir_t *cwd, char *input, int report, int *err);
static void do_an_ls(Dir_t *cwd,char *input, int *err);
static void check_dir_size(Dir_t *cwd, char *input);
static void print_data_description(Dir_t *cwd,int *err);
static void print_data(Dir_t *cwd,int *err);
static int  inlimits(int ndims, int *dims, int *range, int *indexs, int index);
static void print_tree(char *input);
static void print_the_kids(int nblanks, double pid, FILE *fout, 
                     int report_labels,int report_datatype);

static void adftools(Dir_t *cwd);
static void adftranslate();
static void adfbrowse();
*/
extern void build_test_path(char *name,char *input, char *tp);
extern void do_a_cd(Dir_t *cwd, char *input, int report, int *err);
extern void do_an_ls(Dir_t *cwd,char *input, int *err);
extern void check_dir_size(Dir_t *cwd, char *input);
extern void print_data_description(Dir_t *cwd,int *err);
extern void print_data(Dir_t *cwd,int *err);
extern void print_tree(char *input);
extern void print_the_kids(int depth, int *bar, double pid, FILE *fout, 
                     Flags_t flags);

extern void adftools(Dir_t *cwd);
extern void adftranslate();
extern void adfbrowse();

extern void adf_to_p3d();
extern void plot3d_to_adf();
extern void adf_to_plot3d();
extern void p3d_to_adf();

char scratch[256];
/*
main()
{
  char line[1024];
  char *comptr, *ptr;

  while(1) 
  {
    main_screen();
    printf("\nADFmain> " ) ;
    gets( line ) ;

    comptr = line; 
    while(*comptr == ' ' && (comptr - line) <= strlen(line)) comptr++;

    if(strcmp(comptr,"br") == 0)
    {
      adfbrowse();
    }
    else if(strcmp(comptr,"tr") == 0)
    {
      adftranslate();
    }
    else if(strncmp(comptr,"?",1) == 0)
    {
      ptr = comptr+1; 
      while(*ptr == ' ' && (ptr - comptr) <= strlen(comptr)) ptr++;
      main_help(ptr);
    }
    else if(strcmp(comptr,"q") == 0)
    {
      break; 
    }
    else
    {
      printf("Unrecognized command: %s\n",line);
    }
  }
}
*/
void adftranslate()
{
  int err;
  char *comptr, *ptr;

  char    line[1024];


  translator_screen();
  while( 1 ) 
  {
    printf("\nADFtranslate> " ) ;
    gets( line ) ;

    comptr = line; 
    while(*comptr == ' ' && (comptr - line) <= strlen(line)) comptr++;

    if(strncmp(comptr,"1",1) == 0)
    {
      plot3d_to_adf();
    }
    else if(strncmp(comptr,"2",1) == 0)
    {
      adf_to_plot3d();
    }
    else if(strncmp(comptr,"?",1) == 0)
    {
      ptr = comptr+1; 
      while(*ptr == ' ' && (ptr - comptr) <= strlen(comptr)) ptr++;
      translator_help(ptr);
    }
    else if(strncmp(comptr,"q",1) == 0)
    {
      printf("Exiting the program...\n");
      exit(0);
    }
    else if(strncmp(comptr,"b",1) == 0)
    {
      break;
    }
    else
    {
      printf("Unrecognized command: %s\n",line);
    }
  }
}
void plot3d_to_adf()
{
  p3d_to_adf();
}
void adf_to_plot3d()
{
  adf_to_p3d();
}


void adfbrowse()
{
  static Dir_t *cwd = 0L;

  int err;
  char *ptr, *comptr;
  int         one = 1,
      name_length = 33;
  int ic, ilen_ret;
  int nchildren;
  char  name[33];
  char label[33];
  char  stub[33];
  int report;

  int    j;
  char    line[1024];

  if(cwd == NULL)
  {
    cwd = (Dir_t *)malloc((unsigned)(sizeof(Dir_t)));
    cwd->nlevelsmax = 10; /* inialize space for 10 levels */
    cwd->name = (char *)malloc((unsigned)((cwd->nlevelsmax*33+1)*sizeof(char)));
    for(j=0; j<cwd->nlevelsmax*33; j++)
      cwd->name[j] = 0;
  }

  browser_screen();
  sprintf(cwd->name,"/");
  fileopen = FALSE;
  while( 1 ) 
  {
    printf("\nADFbrowse> " ) ;
    gets( line ) ;

    comptr = line; 
    while(*comptr == ' ' && (comptr - line) <= strlen(line)) comptr++;

    if(strncmp(comptr,"pwd",3) == 0)
    {
      if(fileopen)
        printf("%s\n",cwd->name);
      else
        printf("No database open\n");
    }
    else if(strncmp(comptr,"?",1) == 0)
    {
      ptr = comptr+1; 
      while(*ptr == ' ' && (ptr - comptr) <= strlen(comptr)) ptr++;
      browser_help(ptr);
    }
    else if(strncmp(comptr,"o",1) == 0)
    {
      ptr = comptr+1; 
      while(*ptr == ' ' && (ptr - comptr) <= strlen(comptr)) ptr++;

      sprintf(status,"OLD");
      sprintf(format,"NATIVE");
      ADF_Database_Open(ptr, status, format, &root_ID, &err);
      if(err > 0) err_exit("ADF_Database_Open",err);

      cwd->id = root_ID;
      fileopen = TRUE;
    }
    else if(strncmp(comptr,"z",1) == 0)
    {
      if(fileopen)
      {
        ADF_Database_Close(root_ID, &err);
        if(err > 0) err_exit("ADF_Database_Close",err);
        fileopen = FALSE;
      }
      else
        printf("No database open\n");
    }
    else if(strncmp(comptr,"q",1) == 0)
    {
      printf("Exiting the program...\n");
      /* wrj: should have some cleanup here ie close open
              files???  */
      exit(0);
    }
    else if(strncmp(comptr,"cd",2) == 0)
    {
      if(fileopen)
      {
        ptr = comptr + 2;
        report = TRUE;
        do_a_cd(cwd,ptr,report,&err);
      }
      else
        printf("No database open\n");
    }
    else if(strncmp(comptr,"ls",2) == 0)
    {
      if(fileopen)
      {
        ptr = comptr + 2;
        do_an_ls(cwd,ptr,&err);
      }
      else
        printf("No database open\n");
    }
    else if(strncmp(comptr,"dd",2) == 0)
    {
      if(fileopen)
      {
        print_data_description(cwd,&err);
      }
      else
        printf("No database open\n");
    }
    else if(strncmp(comptr,"pd",2) == 0)
    {
      if(fileopen)
      {
        print_data(cwd,&err);
      }
      else
        printf("No database open\n");
    }
    else if(strncmp(comptr,"t",2) == 0)
    {
        adftools(cwd);
        browser_screen();
    }
    else if(strncmp(comptr,"b",1) == 0)
    {
      break;
    }
    else
    {
      printf("Unrecognized command: %s\n",line);
    }

  }

}
void adftools(Dir_t *cwd)
{
  char *comptr, *ptr;

  char line[1024];


  tools_screen();
  while( 1 ) 
  {
    printf("\nADFtools> " ) ;
    gets( line ) ;

    comptr = line; 
    while(*comptr == ' ' && (comptr - line) <= strlen(line)) comptr++;

    if(strncmp(comptr,"pt",2) == 0)
    {
      ptr = comptr+2; 
      while(*ptr == ' ' && (ptr - comptr) <= strlen(comptr)) ptr++;
      print_tree(ptr);
    }
    else if(strncmp(comptr,"lc",2) == 0)
    {
      printf("lc option not available yet...\n");
    }
    else if(strncmp(comptr,"fl",2) == 0)
    {
      printf("fl option not available yet...\n");
    }
    else if(strncmp(comptr,"cdb",3) == 0)
    {
      printf("cdb option not available yet...\n");
    }
    else if(strncmp(comptr,"sdb",3) == 0)
    {
      printf("sdb option not available yet...\n");
    }
    else if(strncmp(comptr,"?",1) == 0)
    {
      ptr = comptr+1; 
      while(*ptr == ' ' && (ptr - comptr) <= strlen(comptr)) ptr++;
      tools_help(ptr);
    }
    else if(strncmp(comptr,"q",1) == 0)
    {
      printf("Exiting the program...\n");
      exit(0);
    }
    else if(strncmp(comptr,"b",1) == 0)
    {
      break;
    }
    else
    {
      printf("Unrecognized command: %s\n",line);
    }
  }
}

void build_test_path(char *cwd,char *input, char *tp)
{
  char *ptr, *eptr;


    /* see if input is an absolute path */

  if(input[0] == '/')
  {
    strcpy(tp,input);
    return;
  }

    /* check for null path name input */

  if(input == NULL)
  {
    sprintf(tp,"/"); /* cd 'blank' = a cd to root */
    return;
  }

    /* now build up tp from cwd and input */

  strcpy(tp,cwd);

  ptr = strtok(input,"/");

  if(ptr == NULL) /* nothing but a '/' */
  {
    sprintf(tp,"/"); 
    return;
  }

  while(1)
  {
    if( ptr == NULL) /* done */
    {
      return;
    }

    if(strcmp(ptr,".") == 0) /* do nothing */
      ;
    else if(strcmp(ptr,"..") == 0) /* go up one node */
    {
      if(strcmp(tp,"/") == 0)
        ;
      else
      {
        eptr = &tp[strlen(tp)-1];

          /* backtrack to first '/' */

        while(*eptr != '/' && eptr > tp) eptr--;
        
        if(eptr == tp)
        {
          eptr++;
        }

        *eptr = '\0';
      }
    }else                     /* concatenate */
    {
      if(strcmp(tp,"/") != 0) strcat(tp,"/");
      strcat(tp,ptr);
    }


    ptr = strtok(NULL,"/");
  }
}
void check_dir_size(Dir_t *dir, char *input)
{
  char *tmp, *ptr;
  int c1, c2, ctotal;

    /* Count the number of "/" characters in dir->name and input;
       if the sum of the 2 is at most dir->nlevelsmax, then 
       dir->name is large enough to hold the new name; otherwise,
       increase it.                                              */

  tmp = (char *)malloc((unsigned)((strlen(dir->name)+1)*sizeof(char)));
  strncpy(tmp,dir->name,strlen(dir->name)+1);

  c1 = 1;
  ptr = strtok(tmp,"/");
  while(1)
  {
    if(( ptr = strtok(NULL,"/")) == NULL)
      break;
    else
      c1++;
  }
  free(tmp);

  tmp = (char *)malloc((unsigned)((strlen(input)+1)*sizeof(char)));
  strncpy(tmp,input,strlen(input)+1);

  c2 = 1;
  ptr = strtok(tmp,"/");
  while(1)
  {
    if(( ptr = strtok(NULL,"/")) == NULL)
      break;
    else
      c2++;
  }
  free(tmp);

  ctotal = (c1 + c2);

  if(ctotal <= dir->nlevelsmax)  return; /* space is ok */

  dir->nlevelsmax = ctotal;
  tmp = dir->name;
  dir->name = (char *)realloc(tmp,(dir->nlevelsmax*33+1)*sizeof(char));
}
void err_exit(char *name, int error_return)
{
  sprintf(scratch,"Error return from %s; errno = %d",name,error_return);
  /* just do it as a warning for the time being */
  /*
  fatal(scratch);
  */
  printf("%s\n",scratch);
  ADF_Error_Message(error_return,scratch);
  printf("%s\n",scratch);
}
void do_a_cd(Dir_t *cwd, char *input, int report, int *err)
{
  char *ptr, *inputcopy;
  char *tmpcwd;
  int nchildren, ic, ilen_ret, baselength;
  char stub[33], tempname[33];
  char  name[33];
  char *basename;
  double tmpid;
  int match;

  *err = -1;

    /* make sure the components in the input are small enough */

  inputcopy = (char *)malloc((unsigned)((strlen(input)+1)*sizeof(char)));
  strncpy(inputcopy,input,strlen(input)+1);

  ptr = strtok(inputcopy,"/ ");
  if(ptr != NULL)
  {
    if(strlen(ptr) > 32)
    {
      if(report == TRUE) printf("Input node name is too long!\n");
      free(inputcopy);
      *err = 1;
      return;
    }
    while(1)
    {
      if(( ptr = strtok(NULL,"/ ")) == NULL)
        break;

      if(strlen(ptr) > 32)
      {
        if(report == TRUE) printf("Input node name is too long!\n");
        free(inputcopy);
        return;
      }
    }
  }

    /* input is legal sized; check to see that cwd is 
       large enough to hold it                        */

  check_dir_size(cwd, input);

    /* set up enough space to hold new pathname */

  tmpcwd = (char *)malloc((unsigned)((cwd->nlevelsmax*33+1)*sizeof(char)));

    /* get copy of input and space past blanks */

  strncpy(inputcopy,input,strlen(input)+1);
  ptr = inputcopy; 
  while(*ptr == ' ' && (ptr - inputcopy) <= strlen(inputcopy)) ptr++;

    /* build new path */

  build_test_path(cwd->name,ptr,tmpcwd);

    /* done with inputcopy */

  free(inputcopy);

    /* If new path is just the root, finish. */

  if(strlen(tmpcwd) == 1)
  {
    cwd->id = root_ID;
    sprintf(cwd->name,"/");
    free(tmpcwd);
    return;
  }

    /* process new path name */


  /* In case the user inputs an abbreviation of the subnode
     name, check the end of tmpcwd to see if it needs 
     expansion into a full-fledged name.  An assumption
     here is that tmpcwd always begins with /.  */

    /* point to the end */

  ptr = tmpcwd + strlen(tmpcwd) - 1;

  if(*ptr == '/') /* path can't end in / if not at root */
  {
    if(report == TRUE) printf("Unable to cd to %s\n",input);
    *err = 1;
    free(tmpcwd);
    return;
  }
    /* get the basename (ie the name of the parent node) and ID */

  while(*ptr != '/' && (ptr-tmpcwd) >= 0) ptr--;
  if((ptr-tmpcwd) > 0) baselength = ptr-tmpcwd;
  else                 baselength = 1;
  basename = (char *)malloc((unsigned)((baselength+1)*sizeof(char)));
  strncpy(basename,tmpcwd,baselength);
  basename[baselength] = '\0';

  if(baselength > 1)
    ADF_Get_Node_ID(cwd->id,basename,&tmpid,err);
  else
    tmpid = root_ID;

  if(*err > 0)
  {
    if(report == TRUE)
    {
      err_exit("ADF_Get_Node_ID",*err);
      printf("Unable to cd to %s\n",input);
    }
    free(tmpcwd);
    free(basename);
    return;
  }

    /* now figure out which (if any) of the children matches
       uniquely the rest of tmpcwd */

  strncpy(stub,ptr+1,32);
  stub[32] = '\0';

  nchildren = 0;
  ADF_Number_of_Children(tmpid,&nchildren,err);
  match = FALSE;
  for(ic=1; ic<=nchildren; ic++)
  {
    ADF_Children_Names(tmpid,ic,1,33,&ilen_ret,name,err);
    if(strncmp(stub,name,strlen(stub)) == 0)
    {
      if(match == TRUE) /* 2nd stub match; input is ambiguous */
      {
        if(report == TRUE) printf("Input is ambiguous\n");
        free(tmpcwd);
        free(basename);
        return;
      }
      else
      {
        match = TRUE;
        strcpy(tempname,name); 
      }
    }
  }
  if(match == FALSE) /* no stub match at all */
  {
    if(report == TRUE) printf("Unable to cd to %s\n",input);
    *err = 2;
    free(tmpcwd);
    free(basename);
    return;
  }

    /* extend the stub on tmpcwd */

  if(baselength > 1)
    sprintf(tmpcwd,"%s/%s",basename,tempname);
  else
    sprintf(tmpcwd,"/%s",tempname);

  ADF_Get_Node_ID(cwd->id,tmpcwd,&tmpid,err);
  if(*err <= 0)
  {
    cwd->id = tmpid;
    strcpy(cwd->name,tmpcwd);
  }else
  {
    if(report == TRUE)
    {
      printf("Unable to cd to %s\n",input);
      err_exit("ADF_Get_Node_ID",*err);
    }
  }
  free(tmpcwd);
  free(basename);
}
void do_an_ls(Dir_t *cwd,char *input, int *err)
{
  int report;
  int report_labels, report_nodetype;
  int flags_done, directories_done;
  int nonblank;
  char *ptr;
  char *inputcopy;
  Dir_t *tmpcwd;
  int tmpcwdspace;
  double tmpid;
  char **pathnames;
  int npathnames;
  int         one = 1,
      name_length = 33;
  int ic, ilen_ret;
  int nchildren;
  char label[33];
  char  name[33];
  int i;

  inputcopy = NULL;
  pathnames = NULL;

    /* Begin by parsing the command; input comes in spaced
       to begin at the character after "ls".  Determine
       1) which flags
       2) the number of directories
       3) which directories                                */

    /* allocate pointers to 100 pathnames */

  pathnames = (char **)malloc((unsigned)(100*sizeof(char *)));

    /* check for all blank input after the ls */

  nonblank = FALSE;
  ptr = input;
  for(i=0; i<strlen(input); i++)
    if(ptr[i] != ' ')
      nonblank = TRUE;

  if(nonblank == FALSE) /* nothing to parse */
  {
    npathnames = 1;
    pathnames[0] = (char *)malloc((unsigned)((strlen(cwd->name)+1)*sizeof(char)));
    strcpy(pathnames[0],cwd->name);
  }
  else    /* parse it */
  {

    inputcopy = (char *)malloc((unsigned)((strlen(input)+1)*sizeof(char)));
    strncpy(inputcopy,input,strlen(input)+1);

    flags_done      = FALSE;
    directories_done  = FALSE;
    report_labels   = FALSE;
    report_nodetype = FALSE;
    npathnames = 0;

    ptr = strtok(inputcopy," ");
    while(1)
    {
      if(*ptr == '-')  /* flags */
      {
        if(flags_done || directories_done)
        {
          printf("Usage: ls -lt [paths]\n");
          free(inputcopy);
          free(pathnames);
          return;
        }

        if(strlen(ptr) < 2)
        {
          printf("-: no such node\n");
          free(inputcopy);
          free(pathnames);
          return;
        }
        for(i=1; i<strlen(ptr); i++)
        {
          switch(*(ptr+i))
          {
            case 't':
              report_nodetype = TRUE;
              break;
            case 'l':
              report_labels = TRUE;
              break;
            default:
              printf("Usage: ls -lt [files]\n");
              if(inputcopy != NULL) free(inputcopy);
              free(pathnames);
              return;
          }
        }
      }
      else  /* pathnames */
      {
        flags_done       = TRUE;
        directories_done = TRUE;

        if(npathnames < 100) /* ignore more than 100 */
        {
          pathnames[npathnames] = (char *)malloc((unsigned)((strlen(ptr)+1)*sizeof(char)));
          strcpy(pathnames[npathnames],ptr);
          npathnames++;

        }else
          printf("Ignoring pathnames past the first 100.\n");
      }

      if(( ptr = strtok(NULL," ")) == NULL)
        break;
    }
      /* if no directory name explicitly given, just do current */

    if(directories_done == FALSE)
    {
      npathnames = 1;
      pathnames[0] = (char *)malloc((unsigned)((strlen(cwd->name)+1)*sizeof(char)));
      strcpy(pathnames[0],cwd->name);
    }

      /* flags are set and pathnames are loaded;  done with
         the inputcopy */

    free(inputcopy);
  }


       /* main loop over requested paths */

    /* Make a copy of cwd to be used in this routine to do
       cds and then ls.  The copy will not affect the primary
       cwd.  */

  tmpcwd = (Dir_t *)malloc((unsigned)(sizeof(Dir_t)));
  tmpcwd->name = (char *)malloc((unsigned)((strlen(cwd->name)+1)*sizeof(char)));


  for(i=0; i<npathnames; i++)
  {
    strcpy(tmpcwd->name,cwd->name);
    tmpcwd->id = cwd->id;
    tmpcwd->nlevelsmax = cwd->nlevelsmax;

    check_dir_size(tmpcwd, pathnames[i]);

    report = FALSE;
    do_a_cd(tmpcwd,pathnames[i],report,err);

    if(*err != -1)
    {
      printf("%s:  Bad pathname\n",pathnames[i]);
    }
    else
    {
      if(npathnames > 1)
        printf("\n%s:\n",pathnames[i]);

      ADF_Number_of_Children(tmpcwd->id,&nchildren,err);
      if(nchildren == 0)
        printf("Node has no children.\n");
      else
      {
        printf("# of children: %d\n",nchildren);
        if(report_nodetype == TRUE)
          printf("<node is not a link>\n"); /* or that it is a link */

        for(ic=1; ic<=nchildren; ic++)
        {
          ADF_Children_Names(tmpcwd->id,ic,one,name_length,&ilen_ret,name,err);
          if(report_labels == TRUE)
          {
            ADF_Get_Node_ID(tmpcwd->id,name,&tmpid,err);
            ADF_Get_Label(tmpid,label,err);
            printf("%s (%s) ",name,label);
            if(ic%2 == 0) printf("\n");
          }else
          {
            printf("%s ",name);
            if(ic%4 == 0) printf("\n");
          }
        }
        printf("\n");
      }
    }
  }
  free(tmpcwd->name);
  free(tmpcwd);

  for(i=0; i<npathnames; i++)
    free(pathnames[i]);
  free(pathnames);

}
void print_data_description(Dir_t *cwd,int *err)
{
  char data_type[33];
  int num_dims;
  int dim_vals[13];
  int i;

    /* Node Label */

  ADF_Get_Label(cwd->id,data_type,err);
  if(*err < 0)
  {
    printf("Node Label:  %s\n",data_type);
  }else
  {
    err_exit("ADF_Get_Label",*err);
  }

    /* Data Type */

  ADF_Get_Data_Type(cwd->id,data_type,err);
  if(*err < 0)
  {
    printf("Data Type:  %s\n",data_type);
  }else
  {
    err_exit("ADF_Get_Data_Type",*err);
  }

    /* Number of Dimensions */

  ADF_Get_Number_of_Dimensions(cwd->id,&num_dims,err);
  if(*err < 0)
  {
    printf("Data Dimensions:  %d\n",num_dims);
  }else
  {
    err_exit("ADF_Get_Number_of_Dimensions",*err);
  }

    /* Dimension Values */

  if(num_dims > 0)
  {
    ADF_Get_Dimension_Values(cwd->id,dim_vals,err);
    if(*err < 0)
    {
      printf("Dimension Values:  ");
      for(i=0; i<num_dims; i++)
      {
        if(i==0) printf("( ");
        printf("%d",dim_vals[i]);
        if(i!=num_dims-1) printf(", ");
        if(i==num_dims-1) printf(" )\n");
      }
    }else
    {
      err_exit("ADF_Get_Dimension_Values",*err);
    }
  }else
  {
    printf("Dimension Values:  (None)\n");
  }
}
void print_data(Dir_t *cwd,int *err)
{
  const char SEPCHARS[]=" ,\n";
  char *word;
  char data_type[33], ans[40];
  int num_dims;
  int dim_vals[13], range[13], indexs[13];
  int i, j, isize, nlines;
  int *idat;
  float *fdat;
  double *ddat;
  char *cdat;

    /* Data Type */

  ADF_Get_Data_Type(cwd->id,data_type,err);
  if(*err > 0) err_exit("ADF_Get_Data_Type",*err);

    /* Number of Dimensions */

  ADF_Get_Number_of_Dimensions(cwd->id,&num_dims,err);
  if(*err > 0) err_exit("ADF_Get_Number_of_Dimensions",*err);
  if(num_dims < 1)
  {
    printf("Current node has 0 dimension\n");
    return;
  }

    /* Dimension Values */

  ADF_Get_Dimension_Values(cwd->id,dim_vals,err);
  if(*err > 0) err_exit("ADF_Get_Dimension_Values",*err);
  for(i=num_dims; i<13; i++ ) dim_vals[i]=1; /* Set the rest for ranging */

    /* Print current data limits and calculate the size of the data and
       initialize range arrays */

  isize = 1;
  printf("Dimension Values:  ");
  for(i=0; i<num_dims; i++)
  {
    isize *= dim_vals[i];
    if(i==0) printf("( ");
    printf("%d",dim_vals[i]);
    if(i!=num_dims-1) printf(", ");
    if(i==num_dims-1) printf(" )\n");
    if( i % 2 == 1 ) 
      range[i] = dim_vals[i/2];
    else
      range[i] = 1;
  }

    /* Prompt for a range to print */

  while (1)
    {
      printf("Input a range to print, <cr> for default. Format d1beg d1end d2beg d2end...\n");
      printf("Fortran Range:");
      fgets(ans,40,stdin);
      if ( strlen(ans) <= 1 ) break; 
      i = 0;
      word=strtok(ans,SEPCHARS);
      while ( word != NULL )
      {
        range[i]=atoi(word);
        if ( range[i] < 0 || range[i] > dim_vals[i/2] ) 
        {
          printf("Error parsing range, Try again!\n");
          break;
	}
        word=strtok(NULL,SEPCHARS);
        i++;
      }
        /* If we have all the ranges */
      if ( i/2 == num_dims ) break;
    }

    /* Allocate memory and read the data */

  if ( strncmp ( "I4", data_type, 2 ) == 0 )
  {
      idat = (int *)malloc(isize*sizeof(int));
      if ( idat == NULL )
      {
        printf("Error allocating memory for data\n");
        return;    
      }
      ADF_Read_All_Data(cwd->id,(char *)idat,err);
      if(*err > 0) err_exit("ADF_Read_All_Data",*err);
  } else if ( strncmp ( "R4", data_type, 2 ) == 0 )
    {
      fdat = (float *)malloc(isize*sizeof(float));
      if ( fdat == NULL )
      {
        printf("Error allocating memory for data\n");
        return;    
      }
      ADF_Read_All_Data(cwd->id,(char *)fdat,err);
      if(*err > 0) err_exit("ADF_Read_All_Data",*err);
  } else if ( strncmp ( "R8", data_type, 2 ) == 0 )
    {
      ddat = (double *)malloc(isize*sizeof(double));
      if ( ddat == NULL )
      {
        printf("Error allocating memory for data\n");
        return;    
      }
      ADF_Read_All_Data(cwd->id,(char *)ddat,err);
      if(*err > 0) err_exit("ADF_Read_All_Data",*err);
   } else if ( strncmp ( "C1", data_type, 2 ) == 0 )
    {
      cdat = (char *)malloc(isize*sizeof(char));
      if ( cdat == NULL )
      {
        printf("Error allocating memory for data\n");
        return;    
      }
      ADF_Read_All_Data(cwd->id,(char *)cdat,err);
      if(*err > 0) err_exit("ADF_Read_All_Data",*err);
 } else
    {
      printf("Data type not supported\n");
      return;
  }

    /* Print the data */

  nlines = 0;
  printf("Index_Numbers     Data\n");
  for(i=0; i<isize; i++ )
  {
    if ( inlimits( num_dims, dim_vals, range, indexs, i ) == 0 ) continue;
    nlines++;
    if ( nlines > 21 ) 
    {
      printf("Enter return to continue or q to quit ");
      fgets(ans,40,stdin);
      if( strncmp("q", ans, 1) == 0 ) break;          
      nlines = 0;
      printf("Index_Numbers     Data\n");
    }
    for(j=0; j<num_dims; j++)
    {
      if(j == 0) printf("( ");
      printf("%d",indexs[j]);
      if(j != num_dims-1) printf(", ");
      if(j == num_dims-1) printf(" )");
    }
    if ( strncmp ( "I4", data_type, 2 ) == 0 )
      printf("\t\t%d\n", idat[i]);
    else if ( strncmp ( "R4", data_type, 2 ) == 0 )
      printf("\t\t%g\n", fdat[i]);
    else if ( strncmp ( "R8", data_type, 2 ) == 0 )
      printf("\t\t%g\n", ddat[i]);
    else if ( strncmp ( "C1", data_type, 2 ) == 0 )
      printf("\t\t%c\n", cdat[i]);
  }

    /* Free the memory */

    if ( strncmp ( "I4", data_type, 2 ) == 0 )
      free(idat);
    else if ( strncmp ( "R4", data_type, 2 ) == 0 )
      free(fdat);
    else if ( strncmp ( "R8", data_type, 2 ) == 0 )
      free(ddat);
    else if ( strncmp ( "C1", data_type, 2 ) == 0 )
      free(cdat);

}
int inlimits(int ndims, int *dims, int *range, int *indexs, int index)
{
  int i, n;
  int isize, indext;
  int inrange;

    /* Calculate current ijk... values from the dimensions and the 
       current index */

/*  for(n=ndims-1; n>=0; n--) */
  for(n=0; n<ndims; n++)
  {
    isize = 1;
/*    for(i=n; i>0; i-- ) isize *= dims[i]; */
    for(i=n; i<ndims-1; i++ ) isize *= dims[i];

    indext = index;
/*    for(i=n; i>0; i-- ) */
    for(i=ndims-2; i>=n; i-- )
    {
      indext = indext - isize*(int)(indext/isize);
/*      isize /= dims[ndims-i]; */
      isize /= dims[i];
    }
    indexs[n] = indext+1;
    index = (index - indext)/dims[n];
  }

    /* Check if all values are in range */

   inrange = 1;
   for(i=0; i<ndims; i++)
     if( indexs[i] < range[2*i] || indexs[i] > range[2*i+1] ) inrange=0;
   return inrange;
}
void print_tree(char *input)
{
  FILE *fout;
  int nblanks;
  char *inputcopy, *ptr;
  int flags_done, filename_done;
  Flags_t flags;
  int i;
  int bar[MAXDEPTH]; /* bar[0] unused */
  int depth;

  if( !fileopen )
  {
    printf("No database open\n");
    return;
  }

    /* check for null path name input */

  if(*input == NULL)
    fout = stdout; 
  else
  {
    inputcopy = NULL;

    /* Begin by parsing the command; input comes in spaced
       to begin at first non-blank character after "pt".  
       Determine
       1) which flags
       3) the name of the output file                      */

    inputcopy = (char *)malloc((unsigned)((strlen(input)+1)*sizeof(char)));
    strncpy(inputcopy,input,strlen(input)+1);

          flags_done      = FALSE;
          filename_done   = FALSE;
    flags.report_labels   = FALSE;
    flags.report_datatype = FALSE;

    ptr = strtok(inputcopy," ");
    while(1)
    {
      if(*ptr == '-')  /* flags */
      {
        if( flags_done || filename_done)
        {
          printf("Usage: pt -ld [filename]\n");
          free(inputcopy);
          return;
        }

        if(strlen(ptr) < 2)
        {
          printf("-: Bad input\n");
          free(inputcopy);
          return;
        }
        for(i=1; i<strlen(ptr); i++)
        {
          switch(*(ptr+i))
          {
            case 'd':
              flags.report_datatype = TRUE;
              break;
            case 'l':
              flags.report_labels = TRUE;
              break;
            default:
              printf("Usage: pt -ld [filename]\n");
              if(inputcopy != NULL) free(inputcopy);
              return;
          }
        }
      }
      else  /* filename */
      {
        flags_done = TRUE;
      
        if(filename_done == TRUE)
        {
          printf("Ignoring extra input: %s\n",ptr);
          filename_done = TRUE;
        }
        else 
        {
          filename_done = TRUE;

            /* check for file existence */

          if(access(ptr, 0x00) == 0)
          {
            printf("The file %s already exists.  Ok to overwrite?(N = no) > ",ptr);
            gets(scratch);
            if(scratch[0] == 'N' || scratch[0] == 'n')
            {
              free(inputcopy);
              return;
            }
          }


          fout = fopen(ptr,"w");
          if(fout == NULL)
          {
            printf("Unable to open file: %s\n",ptr);
            free(inputcopy);
            return;
          }
        }
      }
      if(( ptr = strtok(NULL," ")) == NULL)
        break;
    }
    if(filename_done == FALSE) /* no filename */
      fout = stdout; 


      /* flags are set and output filename are loaded;  done with
         the inputcopy */

    free(inputcopy);
  }


  fprintf(fout,"root node\n");
  depth = 0;
  print_the_kids(depth,bar,root_ID,fout,flags);

  if(fout != stdout)
    fclose(fout);
}
void print_the_kids(int depth, int *bar, double pid, FILE *fout, Flags_t flags) 
{
  int kidblanks;
  int ic, id;
  int nchildren;
  double kid_id;
  int err;
  int         one = 1,
      name_length = 33;
  int ilen_ret;
  char label[33];
  char  name[33];

  char data_type[33];
  int num_dims;
  int dim_vals[13];
  int i;


  if(depth < MAXDEPTH-1) depth++;

  ADF_Number_of_Children(pid,&nchildren,&err);
  if(nchildren == 0)
    return; 
  else
  {
    for(ic=1; ic<=nchildren; ic++)
    {
      if(ic < nchildren) bar[depth] = 1;
      else               bar[depth] = 0;

      ADF_Children_Names(pid,ic,one,name_length,&ilen_ret,name,&err);
      ADF_Get_Node_ID(pid,name,&kid_id,&err);
      fprintf(fout,"  ");
      for(id=1; id<depth; id++) 
      {
        if(bar[id] == 1)
          fprintf(fout,"|");
        else
          fprintf(fout," ");
        fprintf(fout,"   ");
      }
      fprintf(fout,"+-%s\n",name);

      if(flags.report_labels == TRUE)
      {
        ADF_Get_Label(kid_id,label,&err);
        if(err < 0)
        {
          fprintf(fout,"  ");
          for(id=1; id<depth; id++) 
          {
            if(bar[id] == 1)
              fprintf(fout,"|");
            else
              fprintf(fout," ");
            fprintf(fout,"   ");
          }
          fprintf(fout,"  { Label: %s } \n",label);
        }else
        {
          err_exit("ADF_Get_Label",err);
        }
      }
      if(flags.report_datatype == TRUE)
      {
          /* Data Type */

        ADF_Get_Data_Type(kid_id,data_type,&err);
        if(err < 0)
        {
          fprintf(fout,"  ");
          for(id=1; id<depth; id++) 
          {
            if(bar[id] == 1)
              fprintf(fout,"|");
            else
              fprintf(fout," ");
            fprintf(fout,"   ");
          }
          fprintf(fout,"  { Data Type:  %s }\n",data_type);
        }else
        {
          err_exit("ADF_Get_Data_Type",err);
        }
          /* Number of Dimensions */

        ADF_Get_Number_of_Dimensions(kid_id,&num_dims,&err);
        if(err < 0)
        {
          fprintf(fout,"  ");
          for(id=1; id<depth; id++) 
          {
            if(bar[id] == 1)
              fprintf(fout,"|");
            else
              fprintf(fout," ");
            fprintf(fout,"   ");
          }
          fprintf(fout,"  { Data Dimensions:  %d }\n",num_dims);
        }else
        {
          err_exit("ADF_Get_Number_of_Dimensions",err);
        }

          /* Dimension Values */

        if(num_dims > 0)
        {
          ADF_Get_Dimension_Values(kid_id,dim_vals,&err);
          if(err < 0)
          {
            fprintf(fout,"  ");
            for(id=1; id<depth; id++) 
            {
              if(bar[id] == 1)
                fprintf(fout,"|");
              else
                fprintf(fout," ");
              fprintf(fout,"   ");
            }
            fprintf(fout,"  { Dimension Values:  ");
            for(i=0; i<num_dims; i++)
            {
              if(i==0) fprintf(fout,"  ( ");
              fprintf(fout,"%d",dim_vals[i]);
              if(i!=num_dims-1) fprintf(fout,", ");
              if(i==num_dims-1) fprintf(fout," ) }\n");
            }
          }else
          {
            err_exit("ADF_Get_Dimension_Values",err);
          }
        }else
        {
          fprintf(fout,"  ");
          for(id=1; id<depth; id++) 
    	  {
    		if(bar[id] == 1)
    		  fprintf(fout,"|");
    		else
    		  fprintf(fout," ");
    		fprintf(fout,"   ");
    	  }
          fprintf(fout,"  { Dimension Values:  (None) }\n");
        }
      }

      print_the_kids(depth,bar,kid_id,fout,flags);
    }
  }
}
