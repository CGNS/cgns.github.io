/* this is adfeditincl.c */

#include "fortran_macros.h"
#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include "ADF.h"

void FMNAME(cg_ftubrowse_f, CG_FTUBROWSE_F) () {
	adfbrowse();
}

