/* this is adfeditmisc.c */

#include <stdio.h>
#include <ctype.h>
#include <string.h>

#ifndef FALSE
#define FALSE    0
#endif
#ifndef TRUE
#define TRUE     1
#endif


extern void main_screen();
extern void translator_screen();
extern void browser_screen();
extern void tools_screen();
extern void edit_screen();

extern void main_help(char *input);
extern void translator_help(char *input);
extern void browser_help(char *input);
extern void tools_help(char *input);
extern void edit_help(char *input);


/*******************************************************************
    main_screen()
********************************************************************/
void main_screen()
{
  printf("\n");
  printf("  ADF Utilities Main Screen\n");
  printf("Selections:\n");
/*printf("  tr              : ADF translators.\n");*/
  printf("  br              : ADF browser\n");
  printf("  q               : quit program\n");
  printf("  ? [command]     : Help.\n");
  printf("\n");
}

/*******************************************************************
    translator_screen()
********************************************************************/
void translator_screen()
{
  printf("\n");
  printf("  ADF Translator\n");
  printf("Selections:\n");
  printf("  1               : Convert plot3d to ADF\n");
  printf("  2               : Convert ADF to plot3d\n");
  printf("  b               : Backup to previous menu.\n");
  printf("  q               : quit program\n");
  printf("  ? [command]     : Help.\n");
  printf("\n");
}

/*******************************************************************
    browser_screen()
********************************************************************/
void browser_screen()
{
  printf("\n");
  printf("  ADF Browser:\n");
  printf("Selections:\n");
  printf("  o filename      : Open an existing database.\n");
  printf("  z               : Close the open database.\n");
  printf("  pwd             : Print current node.\n");
  printf("  cd              : Change current node.\n");
  printf("  ls              : List children of current node.\n");
  printf("  dd              : Print description of node data.\n");
  printf("  pd              : Print node data.\n");
  printf("  t               : Miscellaneous ADF tools menu.\n");
  printf("  e               : Node editing menu.\n");
  printf("  b               : Backup to previous menu.\n");
  printf("  q               : Quit this program.\n");
  printf("  ? [command]     : Help.\n");
  printf("\n");



  /*
  printf("      n PID name usage: Create a new thing under the parent ID\n" ) ;
  printf("      h ID          : Display a thing's header\n" ) ;
  printf("      d ID          : Delete an existing thing\n" ) ;
  printf("      g# ID         : Get the number of children of the thing\n" ) ;
  printf("      gc ID         : Get the children's names of a thing\n" ) ;
  printf("      gi PID name   : Get ID of child given PID and child's name\n" ) ;
  printf("      gn ID         : Get the name of a thing\n" ) ;
  printf("      gp ID         : Get the parent's ID of a thing\n" ) ;
  printf("      pn ID name    : Put the name of a thing\n" ) ;
  printf("      dt ID         : Get the data-type of a thing\n" ) ;
  printf("      dd ID         : Get the number of dimensions of a thing\n" ) ;
  printf("      dv ID         : Get the dimension values of a thing\n" ) ;
  printf("      pd ID d-type dims dim-vals : Put/change data/dim information\n");
  printf("      r ID          : Read the data from a thing\n" ) ;
  printf("      w ID value i j k... : Write a single data value\n" ) ;
  */
}

/*******************************************************************
    tools_screen()
********************************************************************/
void tools_screen()
{
  printf("\n");
  printf("  ADF Miscellaneous Tools\n");
  printf("Selections:\n");
  printf("  pt  [filename] : Print file hierarchy to a file.\n");
  printf("  lc             : Check for loops in hierarchy.\n");
  printf("  td             : Report longest path in hierarchy.\n");
  printf("  fl             : List all files involved in database.\n");
  printf("  cdb [filename] : Collect database into one file.\n");
  printf("  sdb filename   : Spread database into multiple files.\n");
  printf("  b              : Backup to previous menu.\n");
  printf("  q              : quit program\n");
  printf("  ?   [command]  : Help.\n");
  printf("\n");
}

/*******************************************************************
    edit_screen()
********************************************************************/
void edit_screen()
{
  printf("\n");
  printf("  ADF Node Editor\n");
  printf("Selections:\n");
  printf("  cn             : Change name of node.\n");
  printf("  cl             : Change label of node.\n");
  printf("  cdd            : Change data description.\n");
  printf("  cdv            : Change data value(s).\n");
  printf("  ac             : Add child to node.\n");
  printf("  b              : Backup to previous menu.\n");
  printf("  q              : quit program\n");
  printf("  ?   [command]  : Help.\n");
  printf("\n");
}

/*******************************************************************
    main_help()
********************************************************************/
void main_help(char *input)
{

  if(*input == '\0')
  {
    main_screen();
    return;
  }
  else if(strcmp(input,"br") == 0)
  {
    printf("br\n");
    printf("  Start a browser to inspect the data and structure \n");
    printf("  in an ADF file.\n");
  }
  else if(strcmp(input,"tr") == 0)
  {
    printf("tr\n");
    printf("  Access a set of translators related to ADF files.\n");
  }
  else if(strcmp(input,"?") == 0)
  {
    printf("? [command]\n");
    printf("  Help.  By itself, redisplays menu; followed\n");
    printf("  by a command, gives information on the command.\n");
  }
  else if(strcmp(input,"q") == 0)
  {
    printf("q\n");
    printf("  Quits this program.\n");
  }
  else
  {
    printf("No help on: %s\n",input);
  }

}

/*******************************************************************
    translator_help()
********************************************************************/
void translator_help(char *input)
{

  if(*input == '\0')
  {
    translator_screen();
    return;
  }
  else if(strcmp(input,"1") == 0)
  {
    printf("p3d_to_adf\n");
    printf("  Translate the data in a plot3d file to ADF format.\n");
  }
  else if(strcmp(input,"2") == 0)
  {
    printf("adf_to_p3d\n");
    printf("  Translate the data in an ADF file to plot3d format.\n");
  }
  else if(strcmp(input,"?") == 0)
  {
    printf("? [command]\n");
    printf("  Help.  By itself, redisplays menu; followed\n");
    printf("  by a command, gives information on the command.\n");
  }
  else if(strcmp(input,"q") == 0)
  {
    printf("q\n");
    printf("  Quits this program.\n");
  }
  else if(strcmp(input,"b") == 0)
  {
    printf("b\n");
    printf("  Return to the previous menu.\n");
  }
  else
  {
    printf("No help on: %s\n",input);
  }

}

/*******************************************************************
    browser_help()
********************************************************************/
void browser_help(char *input)
{

  if(*input == '\0')
  {
    browser_screen();
    return;
  }
  else if(strcmp(input,"pwd") == 0)
  {
    printf("pwd\n");
    printf("  Prints the name of the current node.\n");
  }
  else if(strcmp(input,"?") == 0)
  {
    printf("? [command]\n");
    printf("  Help.  By itself, redisplays menu; followed\n");
    printf("  by a command, gives information on the command.\n");
  }
  else if(strcmp(input,"o") == 0)
  {
    printf("o filename \n");
    printf("  Open an ADF file as OLD in NATIVE format.\n");
  }
  else if(strcmp(input,"z") == 0)
  {
    printf("z\n");
    printf("  Close an open ADF file.\n");
  }
  else if(strcmp(input,"q") == 0)
  {
    printf("q\n");
    printf("  Quits this program.\n");
  }
  else if(strcmp(input,"cd") == 0)
  {
    printf("cd [name]\n");
    printf("  Imitates the 'Change Directory' in Unix.\n");
    printf("  The browser maintains a notion of the current\n");
    printf("  node.  This command changes the current node\n");
    printf("  to that of the named node.  If no node is named,\n");
    printf("  it sets the current node to the root node.\n");
    printf("  It understands '.', '..', and relative and \n");
    printf("  absolute pathnames.  It will accept (unambiguous)\n");
    printf("  name abreviations at the end of pathnames but not\n");
    printf("  regular expressions. \n");
  }
  else if(strcmp(input,"ls") == 0)
  {
    printf("ls -lt [names]\n");
    printf("  Imitates the 'List Directory' in Unix.\n");
    printf("  If no arguements are given, the names of the\n");
    printf("  children of the current node are given.  Otherwise\n");
    printf("  the children of the named nodes are listed.\n");
    printf("  Recognized names are the same as for 'cd'.\n");
    printf("  Flags:\n");
    printf("    -l (label) lists the label of the named node\n");
    printf("    -t (type)  states whether or not node is a link\n");
  }
  else if(strcmp(input,"dd") == 0)
  {
    printf("dd\n");
    printf("  Display the label and the type and dimensions of \n");
    printf("  data at the current node.\n");
  }
  else if(strcmp(input,"pd") == 0)
  {
    printf("pd\n");
    printf("  Print the data of the current node.\n");
  }
  else if(strcmp(input,"t") == 0)
  {
    printf("t\n");
    printf("  Display menu of some additional tools for \n");
    printf("  working with ADF files.\n");
  }
  else if(strcmp(input,"e") == 0)
  {
    printf("e\n");
    printf("  Display menu of commands to edit the current node.\n");
  }
  else if(strcmp(input,"b") == 0)
  {
    printf("b\n");
    printf("  Return to the previous menu.\n");
  }
  else
  {
    printf("No help on: %s\n",input);
  }

}

/*******************************************************************
    tools_help()
********************************************************************/
void tools_help(char *input)
{

  if(*input == '\0')
  {
    tools_screen();
    return;
  }
  else if(strcmp(input,"pt") == 0)
  {
    printf("pt -ld [filename]\n");
    printf("  Print out a view of the hierarchy int the ADF\n");
    printf("  database.  If filename is omitted, this will\n");
    printf("  print to the screen.\n");
    printf("    -l (label) lists the label of nodes\n");
    printf("    -d (data)  lists data type and size info\n");
    printf("    -v (datavalues)  lists subset of data values \n");
  }
  else if(strcmp(input,"lc") == 0)
  {
    printf("lc\n");
    printf("  This command will search for and report on any\n");
    printf("  loops found in the database hierarchy.\n");
  }
  else if(strcmp(input,"td") == 0)
  {
    printf("td\n");
    printf("  This command will search for and report on the\n");
    printf("  deepest path in the database hierarchy.\n");
  }
  else if(strcmp(input,"fl") == 0)
  {
    printf("fl\n");
    printf("  This command will search for and report on all\n");
    printf("  files involved in the current database.\n");
  }
  else if(strcmp(input,"cdb") == 0)
  {
    printf("cdb [filename]\n");
    printf("  This command will coalesce all nodes in a database\n");
    printf("  into a single file.  If the database is already in\n");
    printf("  a single file, no action will occur.  If no \n");
    printf("  filename is specified, the filename containing the\n");
    printf("  root node of the database will be used.\n");
  }
  else if(strcmp(input,"sdb") == 0)
  {
    printf("sdb filename\n");
    printf("  This command will spread part of a database into\n");
    printf("  a new file.  It will develop a copy of the database\n");
    printf("  hierarchy in the named file down to the current\n");
    printf("  node (as named by the pwd command in the ADFbrowser\n");
    printf("  screen), copy the database from the current node\n");
    printf("  on down into to named file and make the current \n");
    printf("  node in the original file a link.\n");
  }
  else if(strcmp(input,"?") == 0)
  {
    printf("? [command]\n");
    printf("  Help.  By itself, redisplays menu; followed\n");
    printf("  by a command, gives information on the command.\n");
  }
  else if(strcmp(input,"q") == 0)
  {
    printf("q\n");
    printf("  Quits this program.\n");
  }
  else if(strcmp(input,"b") == 0)
  {
    printf("b\n");
    printf("  Return to the previous menu.\n");
  }
  else
  {
    printf("No help on: %s\n",input);
  }

}

/*******************************************************************
    edit_help()
********************************************************************/
void edit_help(char *input)
{

  if(*input == '\0')
  {
    edit_screen();
    return;
  }
  else if(strcmp(input,"cn") == 0)
  {
    printf("cn\n");
    printf("  Change the name of the current adf node.  The\n");
    printf("  new name must be unique amongst the children\n");
    printf("  of the parent of this node.  It also must not\n");
    printf("  exceed 32 characters in length.\n");
  }
  else if(strcmp(input,"cl") == 0)
  {
    printf("cl\n");
    printf("  Change the label of the current adf node.  The\n");
    printf("  new name must not exceed 32 characters in length.\n");
  }
  else if(strcmp(input,"cdd") == 0)
  {
    printf("cdd\n");
    printf("  Change the data description of the node.  This\n");
    printf("  is used to change the datatype, the number of \n");
    printf("  dimensions of the data or the data dimension values.\n");
  }
  else if(strcmp(input,"cdv") == 0)
  {
    printf("cdv\n");
    printf("  Change one or more of the data values stored at the\n");
    printf("  node. \n");
  }
  else if(strcmp(input,"ac") == 0)
  {
    printf("ac\n");
    printf("  This command will let you add a child to this node.\n");
    printf("  You must name the node and you can optionally supply\n");
    printf("  a label.  The data will be set to system defaults \n");
    printf("  and you must return to the previous menu to 'cd' to\n");
    printf("  this node in order to edit it and change the data  \n");
    printf("  defaults.\n");
  }
  else if(strcmp(input,"?") == 0)
  {
    printf("? [command]\n");
    printf("  Help.  By itself, redisplays menu; followed\n");
    printf("  by a command, gives information on the command.\n");
  }
  else if(strcmp(input,"q") == 0)
  {
    printf("q\n");
    printf("  Quits this program.\n");
  }
  else if(strcmp(input,"b") == 0)
  {
    printf("b\n");
    printf("  Return to the previous menu.\n");
  }
  else
  {
    printf("No help on: %s\n",input);
  }

}
