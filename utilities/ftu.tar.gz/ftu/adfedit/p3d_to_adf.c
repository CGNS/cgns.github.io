/* this is p3d_to_adf.c and adf_to_p3d */

/* 
   Need to add a user inquiry to ask if grid contains rind/one-cell 
   overlap anywhere; if so, ask for input? ask for file with rows
   of six ints indicating rind on lo-i, hi-i, lo-j, etc faces? or
   something else?  
*/

/*******************************************************************
    Includes
*******************************************************************/
#include <stdio.h>
#include <fcntl.h>
#include "ADF.h"

/*******************************************************************
    Defines:
*******************************************************************/
#define MAX_DIMENSIONS 12

#ifndef FALSE
#define FALSE    0
#endif
#ifndef TRUE
#define TRUE    (!FALSE)
#endif
#define PERMS    0660
typedef int Boolean;

/*******************************************************************
    Prototypes:
*******************************************************************/
extern  void     open_and_write_adf(char *filename, int fin, int fin2);
extern  void     open_and_read_adf_headers(char *filename);
extern  void     open_and_read_headers(char *name, int *fin);
extern  void     open_and_read_qheaders(char *name, int *fin);
extern  void     open_and_write_p3dx(char *filename);
extern  void     open_and_write_p3dq(char *filename);
extern  void    fatal(char *msg);
extern  void    err_exit(char *name, int error_return);

/*******************************************************************
    Global variables:
*******************************************************************/
int *imax, *jmax, *kmax, ng;
int problemdimension;  /* 1-d 2-d or 3-d?? */

const char Zone_t[33] = "Zone_t\0";

int nchildren;

char filename[256];

double root_id, baseid; /* ADF root and base file pointer */

extern char status[32], format[32];

static char scratch[256];

Boolean QEXISTS = TRUE; /* default is to assume user gives q file */

void p3d_to_adf();
void adf_to_p3d();

/*******************************************************************
    p3d_to_adf:
********************************************************************/
void p3d_to_adf()
{
  int fin, fin2;

/*
  ask_about_plot3d_file();
*/
  problemdimension = 3;  /* hardwire for the time being */
  printf("Input the plot3d grid filename > ");
  gets(filename);
  open_and_read_headers(filename, &fin);

  printf("Input the plot3d field filename (CR for none) > ");
  gets(filename);
  
  fin2 = 0;
  if(strlen(filename) == 0)
    QEXISTS = FALSE;
  else
    open_and_read_qheaders(filename, &fin2);

  printf("Input the ADF filename > ");
  gets(filename);
  unlink(filename);
  open_and_write_adf(filename, fin, fin2);
}
/*******************************************************************/
void open_and_read_headers(char *name, int *fin)
{
  int i;

  *fin = open(name,O_RDONLY );
  if (*fin <= 0)
  {
    printf("\nCOULD NOT OPEN plot3d FILE NAMED %s\n",name);
    exit(1);
  }
   
  if( read(*fin,&ng,(sizeof(int))) != (sizeof(int)))
    fatal("Error reading ng.");
   
  imax = (int *)malloc((unsigned)(ng*sizeof(int)));
  jmax = (int *)malloc((unsigned)(ng*sizeof(int)));
  kmax = (int *)malloc((unsigned)(ng*sizeof(int)));
  if ( imax == NULL || jmax == NULL || kmax == NULL )
     fatal("Error allocating memory");

  for(i=0; i<ng; i++)
  {
    if( read(*fin,&imax[i],(sizeof(int))) != (sizeof(int)))
    {
      sprintf(scratch,"Error reading imax[%d].",i);
      fatal(scratch);
    }
    if( read(*fin,&jmax[i],(sizeof(int))) != (sizeof(int)))
    {
      sprintf(scratch,"Error reading jmax[%d].",i);
      fatal(scratch);
    }
    if( read(*fin,&kmax[i],(sizeof(int))) != (sizeof(int)))
    {
      sprintf(scratch,"Error reading kmax[%d].",i);
      fatal(scratch);
    }

  }
}
/*******************************************************************/
void open_and_read_qheaders(char *name, int *fin)
{
  int i;

  *fin = open(name,O_RDONLY );
  if (*fin <= 0)
  {
    printf("\nCOULD NOT OPEN plot3d q FILE NAMED %s\n",name);
    exit(1);
  }
   
  if( read(*fin,&ng,(sizeof(int))) != (sizeof(int)))
    fatal("Error reading ng.");
   
/*
  imax = (int *)malloc((unsigned)(ng*sizeof(int)));
  jmax = (int *)malloc((unsigned)(ng*sizeof(int)));
  kmax = (int *)malloc((unsigned)(ng*sizeof(int)));
  if ( imax == NULL || jmax == NULL || kmax == NULL )
     fatal("Error allocating memory");
*/

  for(i=0; i<ng; i++)
  {
    if( read(*fin,&imax[i],(sizeof(int))) != (sizeof(int)))
    {
      sprintf(scratch,"Error reading imax[%d].",i);
      fatal(scratch);
    }
    if( read(*fin,&jmax[i],(sizeof(int))) != (sizeof(int)))
    {
      sprintf(scratch,"Error reading jmax[%d].",i);
      fatal(scratch);
    }
    if( read(*fin,&kmax[i],(sizeof(int))) != (sizeof(int)))
    {
      sprintf(scratch,"Error reading kmax[%d].",i);
      fatal(scratch);
    }

  }
}
/*******************************************************************/
void open_and_write_adf(char *filename, int fin, int fin2)
{
  char name[33], label[33];
  int gridsize;
  int iz;
  double oldid, newid;
  double gcid, fsid, zoneid;
  float data[2];
  int intdata[2];
  int dims, dim_vals[MAX_DIMENSIONS];
  int s_start[MAX_DIMENSIONS], s_end[MAX_DIMENSIONS], 
      s_stride[MAX_DIMENSIONS] ;
  int m_num_dims, m_dims[MAX_DIMENSIONS]; 
  int m_start[MAX_DIMENSIONS], m_end[MAX_DIMENSIONS], 
      m_stride[MAX_DIMENSIONS] ;

  int rangeindices[16];
  int range[8];
  float *coord;
  float fourfloats[4];
  int threeints[3];
  int sixints[6];

  int indexdimension[2];

  int error_return;

    /* Create the database */

  sprintf(status,"NEW");
  sprintf(format,"NATIVE");
  ADF_Database_Open(filename, status, format, &root_id, &error_return);
  if(error_return > 0) err_exit("ADF_Database_Open",error_return);

    /* create base node */
  
  sprintf(name,"Base1");
  ADF_Create(root_id,name,&baseid,&error_return);
  if(error_return > 0) err_exit("ADF_Create",error_return);

    /* label base node */

  sprintf(label,"CGNSbase_t");
  ADF_Set_Label(baseid,label,&error_return);     
  if(error_return > 0) err_exit("ADF_Set_Label:CGNSbase_t",error_return);

    /* set dim and dimvals and write problem dimension int data */

/* this is the expected I4 version
*/
  dims = 1;
  dim_vals[0] = 1;
  ADF_Put_Dimension_Information(baseid,"I4",dims,dim_vals,&error_return);     
  if(error_return > 0) err_exit("ADF_Put_Dimension_Information",error_return);

  ADF_Write_All_Data(baseid, (char *)(&problemdimension), &error_return);
  if(error_return > 0) err_exit("ADF_Write_Data",error_return);

/* the following was done just to try writing an "I8" by specifying a dim 2
   int array; guess I don't know if it works without reading it */
/*
  dims = 1;
  dim_vals[0] = 1;
  ADF_Put_Dimension_Information(baseid,"I8",dims,dim_vals,&error_return);     
  if(error_return > 0) err_exit("ADF_Put_Dimension_Information",error_return);

  ADF_Write_All_Data(baseid, (char *)(&indexdimension), &error_return);
  if(error_return > 0) err_exit("ADF_Write_Data",error_return);
*/

    /* main loop */

  for(iz=0; iz<ng; iz++)
  {
      /* create zone node */

    sprintf(name,"Zone%d",iz+1);
    ADF_Create(baseid,name,&zoneid,&error_return);     
    if(error_return > 0) err_exit("ADF_Create",error_return);
    oldid = newid;

      /* label zone node */

    sprintf(label,"Zone_t");
    ADF_Set_Label(zoneid,label,&error_return);     
    if(error_return > 0) err_exit("ADF_Set_Label:Zone_t",error_return);

      /* set dim and dimvals and write zone size int data */

/*
1st crack
    dims = 1;
    dim_vals[0] = 3;
*/
    dims = 2;
    dim_vals[0] = 2;
    dim_vals[1] = problemdimension;
    ADF_Put_Dimension_Information(zoneid,"I4",dims,dim_vals,&error_return);
    if(error_return > 0) err_exit("ADF_Put_Dimension_Information",error_return);

	  /* the following values for vertex (and cell) gridsize MUST NOT include rind if any */

    sixints[0] = imax[iz]; 
    sixints[1] = jmax[iz];
    sixints[2] = kmax[iz];
    sixints[3] = imax[iz] - 1; 
    sixints[4] = jmax[iz] - 1;
    sixints[5] = kmax[iz] - 1;

    ADF_Write_All_Data(zoneid, (char *)sixints, &error_return);
    if(error_return > 0) err_exit("ADF_Write_Data",error_return);

      /* create grid node */

    sprintf(name,"GridCoordinates");
    ADF_Create(zoneid,name,&gcid,&error_return);     
    if(error_return > 0) err_exit("ADF_Create",error_return);

      /* label grid node */

    sprintf(label,"GridCoordinates_t");
    ADF_Set_Label(gcid,label,&error_return);     
    if(error_return > 0) err_exit("ADF_Set_Label:GridCoordinates_t",error_return);

      /*********************/
      /* set up the X node */
      /*********************/

    sprintf(name,"X");
    ADF_Create(gcid,name,&newid,&error_return);     
    if(error_return > 0) err_exit("ADF_Create",error_return);
    oldid = newid;

      /* label X node */

    sprintf(label,"DataArray_t");
    ADF_Set_Label(oldid,label,&error_return);
    if(error_return > 0) err_exit("ADF_Set_Label:dataarray_t",error_return);

    dims = 3; /* a hardwire */

	  /* the following values need to include the rind if any */

    dim_vals[0] = imax[iz];
    dim_vals[1] = jmax[iz];
    dim_vals[2] = kmax[iz];
    ADF_Put_Dimension_Information(oldid,"R4",dims,dim_vals,&error_return);     
    if(error_return > 0) err_exit("ADF_Put_Dimension_Information",error_return);

      /* set up space for coordinate data */

    gridsize = imax[iz] * jmax[iz] * kmax[iz];
    coord = (float *)malloc((unsigned)(gridsize*sizeof(float)));
    if ( coord == NULL ) fatal("Error allocating coord memory!");

      /* write data for X */
    
    if( read(fin,coord,(gridsize*sizeof(float))) != 
                       (gridsize*sizeof(float)))
      fatal("Error reading grid.");

    ADF_Write_All_Data(oldid, (char *)coord, &error_return);
    if(error_return > 0) err_exit("ADF_Write_Data",error_return);
/* wrj:  need to check whether there is any problem here with 
         c vs fortran indexing */
/*
    s_start[0] = 1;  s_end[0] = imax[iz];  s_stride[0] = 1;
    s_start[1] = 1;  s_end[1] = jmax[iz];  s_stride[1] = 1;
    s_start[2] = 1;  s_end[2] = kmax[iz];  s_stride[2] = 1;
    m_num_dims = 3;
    m_dims[0] = imax[iz];
    m_dims[1] = jmax[iz];
    m_dims[2] = kmax[iz];
    m_start[0] = 1;  m_end[0] = imax[iz];  m_stride[0] = 1;
    m_start[1] = 1;  m_end[1] = jmax[iz];  m_stride[1] = 1;
    m_start[2] = 1;  m_end[2] = kmax[iz];  m_stride[2] = 1;

    ADF_Write_Data(oldid, s_start, s_end, s_stride,
                          m_num_dims, m_dims, 
                          m_start, m_end, m_stride, 
                          (char *)coord, &error_return);
    if(error_return > 0) err_exit("ADF_Write_Data",error_return);
*/

      /* set up the units for the X node */

    sprintf(name,"DataUnits");
    ADF_Create(oldid,name,&newid,&error_return);     
    if(error_return > 0) err_exit("ADF_Create",error_return);
    oldid = newid;

      /* label dataunits node */

    sprintf(label,"DataUnits_t");
    ADF_Set_Label(oldid,label,&error_return);
    if(error_return > 0) err_exit("ADF_Set_Label:dataunits_t",error_return);


    /*****************/
    /* X IS FINISHED */
    /*****************/

      /* set up the Y node */

    sprintf(name,"Y");
    ADF_Create(gcid,name,&newid,&error_return);     
    if(error_return > 0) err_exit("ADF_Create",error_return);
    oldid = newid;

      /* label Y node */

    sprintf(label,"DataArray_t");
    ADF_Set_Label(oldid,label,&error_return);
    if(error_return > 0) err_exit("ADF_Set_Label:dataarray_t",error_return);

    dims = 3; /* a hardwire */
    dim_vals[0] = imax[iz];
    dim_vals[1] = jmax[iz];
    dim_vals[2] = kmax[iz];
    ADF_Put_Dimension_Information(oldid,"R4",dims,dim_vals,&error_return);     
    if(error_return > 0) err_exit("ADF_Put_Dimension_Information",error_return);

      /* write data for Y */
    
    if( read(fin,coord,(gridsize*sizeof(float))) != 
                       (gridsize*sizeof(float)))
      fatal("Error reading grid.");

    ADF_Write_All_Data(oldid, (char *)coord, &error_return);
    if(error_return > 0) err_exit("ADF_Write_Data",error_return);

/*
    s_start[0] = 1;  s_end[0] = imax[iz];  s_stride[0] = 1;
    s_start[1] = 1;  s_end[1] = jmax[iz];  s_stride[1] = 1;
    s_start[2] = 1;  s_end[2] = kmax[iz];  s_stride[2] = 1;
    m_num_dims = 3;
    m_dims[0] = imax[iz];
    m_dims[1] = jmax[iz];
    m_dims[2] = kmax[iz];
    m_start[0] = 1;  m_end[0] = imax[iz];  m_stride[0] = 1;
    m_start[1] = 1;  m_end[1] = jmax[iz];  m_stride[1] = 1;
    m_start[2] = 1;  m_end[2] = kmax[iz];  m_stride[2] = 1;

    ADF_Write_Data(oldid, s_start, s_end, s_stride,
                          m_num_dims, m_dims, 
                          m_start, m_end, m_stride, 
                          (char *)coord, &error_return);
    if(error_return > 0) err_exit("ADF_Write_Data",error_return);
*/

      /* set up the units for the Y node */

    sprintf(name,"DataUnits");
    ADF_Create(oldid,name,&newid,&error_return);     
    if(error_return > 0) err_exit("ADF_Create",error_return);
    oldid = newid;

      /* label dataunits node */

    sprintf(label,"DataUnits_t");
    ADF_Set_Label(oldid,label,&error_return);
    if(error_return > 0) err_exit("ADF_Set_Label:dataunits_t",error_return);


    /*****************/
    /* Y IS FINISHED */
    /*****************/

      /* set up the Z node */

    sprintf(name,"Z");
    ADF_Create(gcid,name,&newid,&error_return);     
    if(error_return > 0) err_exit("ADF_Create",error_return);
    oldid = newid;

      /* label Z node */

    sprintf(label,"DataArray_t");
    ADF_Set_Label(oldid,label,&error_return);
    if(error_return > 0) err_exit("ADF_Set_Label:dataarray_t",error_return);

    dims = 3; /* a hardwire */
    dim_vals[0] = imax[iz];
    dim_vals[1] = jmax[iz];
    dim_vals[2] = kmax[iz];
    ADF_Put_Dimension_Information(oldid,"R4",dims,dim_vals,&error_return);     
    if(error_return > 0) err_exit("ADF_Put_Dimension_Information",error_return);

      /* write data for Z */
    
    if( read(fin,coord,(gridsize*sizeof(float))) != 
                       (gridsize*sizeof(float)))
      fatal("Error reading grid.");

    ADF_Write_All_Data(oldid, (char *)coord, &error_return);
    if(error_return > 0) err_exit("ADF_Write_Data",error_return);

/*
    s_start[0] = 1;  s_end[0] = imax[iz];  s_stride[0] = 1;
    s_start[1] = 1;  s_end[1] = jmax[iz];  s_stride[1] = 1;
    s_start[2] = 1;  s_end[2] = kmax[iz];  s_stride[2] = 1;
    m_num_dims = 3;
    m_dims[0] = imax[iz];
    m_dims[1] = jmax[iz];
    m_dims[2] = kmax[iz];
    m_start[0] = 1;  m_end[0] = imax[iz];  m_stride[0] = 1;
    m_start[1] = 1;  m_end[1] = jmax[iz];  m_stride[1] = 1;
    m_start[2] = 1;  m_end[2] = kmax[iz];  m_stride[2] = 1;

    ADF_Write_Data(oldid, s_start, s_end, s_stride,
                          m_num_dims, m_dims, 
                          m_start, m_end, m_stride, 
                          (char *)coord, &error_return);
    if(error_return > 0) err_exit("ADF_Write_Data",error_return);
*/

      /* set up the units for the Z node */

    sprintf(name,"DataUnits");
    ADF_Create(oldid,name,&newid,&error_return);     
    if(error_return > 0) err_exit("ADF_Create",error_return);
    oldid = newid;

      /* label dataunits node */

    sprintf(label,"DataUnits_t");
    ADF_Set_Label(oldid,label,&error_return);
    if(error_return > 0) err_exit("ADF_Set_Label:dataunits_t",error_return);


    /*****************/
    /* Z IS FINISHED */
    /*****************/

  if(QEXISTS == FALSE)
  {
      /* free up space for data */

    free(coord);

    printf("Finished with block %d of %d\n",iz+1,ng);
    continue;
  }

  /************************************************************/
  /************************************************************/
  /************************************************************/
  /*   now do the field                                       */
  /************************************************************/
  /************************************************************/
  /************************************************************/

      /* read four floats */
    
    if( read(fin2,fourfloats,(4*sizeof(float))) != 
                            (4*sizeof(float)))
      fatal("Error reading fourfloats.");

      /* create field node */

    sprintf(name,"FlowSolution");
    ADF_Create(zoneid,name,&fsid,&error_return);     
    if(error_return > 0) err_exit("ADF_Create",error_return);
    oldid = newid;


      /* label field node */

    sprintf(label,"DiscreteData_t");
    ADF_Set_Label(fsid,label,&error_return);     
    if(error_return > 0) err_exit("ADF_Set_Label:discretedata_t",error_return);

      /***********************/
      /* set up the Rho node */
      /***********************/

    sprintf(name,"DensityStatic");
    ADF_Create(fsid,name,&newid,&error_return);     
    if(error_return > 0) err_exit("ADF_Create",error_return);
    oldid = newid;

      /* label Rho node */

    sprintf(label,"DataArray_t");
    ADF_Set_Label(oldid,label,&error_return);
    if(error_return > 0) err_exit("ADF_Set_Label:dataarray_t",error_return);

    dims = 3; /* a hardwire */
    dim_vals[0] = imax[iz];
    dim_vals[1] = jmax[iz];
    dim_vals[2] = kmax[iz];
    ADF_Put_Dimension_Information(oldid,"R4",dims,dim_vals,&error_return);     
    if(error_return > 0) err_exit("ADF_Put_Dimension_Information",error_return);

      /* write data for Rho */
    
    if( read(fin2,coord,(gridsize*sizeof(float))) != 
                       (gridsize*sizeof(float)))
      fatal("Error reading q.");

    s_start[0] = 1;  s_end[0] = imax[iz];  s_stride[0] = 1;
    s_start[1] = 1;  s_end[1] = jmax[iz];  s_stride[1] = 1;
    s_start[2] = 1;  s_end[2] = kmax[iz];  s_stride[2] = 1;
    m_num_dims = 3;
    m_dims[0] = imax[iz];
    m_dims[1] = jmax[iz];
    m_dims[2] = kmax[iz];
    m_start[0] = 1;  m_end[0] = imax[iz];  m_stride[0] = 1;
    m_start[1] = 1;  m_end[1] = jmax[iz];  m_stride[1] = 1;
    m_start[2] = 1;  m_end[2] = kmax[iz];  m_stride[2] = 1;

    ADF_Write_Data(oldid, s_start, s_end, s_stride,
                          m_num_dims, m_dims, 
                          m_start, m_end, m_stride, 
                          (char *)coord, &error_return);
    if(error_return > 0) err_exit("ADF_Write_Data",error_return);

      /* set up the units for the Rho node */

    sprintf(name,"DataUnits");
    ADF_Create(oldid,name,&newid,&error_return);     
    if(error_return > 0) err_exit("ADF_Create",error_return);
    oldid = newid;

      /* label dataunits node */

    sprintf(label,"DataUnits");
    ADF_Set_Label(oldid,label,&error_return);
    if(error_return > 0) err_exit("ADF_Set_Label:dataunits_t",error_return);


    /*******************/
    /* Rho IS FINISHED */
    /*******************/



      /*************************/
      /* set up the Rho*U node */
      /*************************/

    sprintf(name,"MomentumX");
    ADF_Create(fsid,name,&newid,&error_return);     
    if(error_return > 0) err_exit("ADF_Create",error_return);
    oldid = newid;

      /* label Rho*U node */

    sprintf(label,"DataArray_t");
    ADF_Set_Label(oldid,label,&error_return);
    if(error_return > 0) err_exit("ADF_Set_Label:dataarray_t",error_return);

    dims = 3; /* a hardwire */
    dim_vals[0] = imax[iz];
    dim_vals[1] = jmax[iz];
    dim_vals[2] = kmax[iz];
    ADF_Put_Dimension_Information(oldid,"R4",dims,dim_vals,&error_return);     
    if(error_return > 0) err_exit("ADF_Put_Dimension_Information",error_return);

      /* write data for Rho*U */
    
    if( read(fin2,coord,(gridsize*sizeof(float))) != 
                       (gridsize*sizeof(float)))
      fatal("Error reading q.");

    s_start[0] = 1;  s_end[0] = imax[iz];  s_stride[0] = 1;
    s_start[1] = 1;  s_end[1] = jmax[iz];  s_stride[1] = 1;
    s_start[2] = 1;  s_end[2] = kmax[iz];  s_stride[2] = 1;
    m_num_dims = 3;
    m_dims[0] = imax[iz];
    m_dims[1] = jmax[iz];
    m_dims[2] = kmax[iz];
    m_start[0] = 1;  m_end[0] = imax[iz];  m_stride[0] = 1;
    m_start[1] = 1;  m_end[1] = jmax[iz];  m_stride[1] = 1;
    m_start[2] = 1;  m_end[2] = kmax[iz];  m_stride[2] = 1;

    ADF_Write_Data(oldid, s_start, s_end, s_stride,
                          m_num_dims, m_dims, 
                          m_start, m_end, m_stride, 
                          (char *)coord, &error_return);
    if(error_return > 0) err_exit("ADF_Write_Data",error_return);
/*
*/

      /* set up the units for the Rho*U node */

    sprintf(name,"DataUnits");
    ADF_Create(oldid,name,&newid,&error_return);     
    if(error_return > 0) err_exit("ADF_Create",error_return);
    oldid = newid;

      /* label dataunits node */

    sprintf(label,"DataUnits");
    ADF_Set_Label(oldid,label,&error_return);
    if(error_return > 0) err_exit("ADF_Set_Label:dataunits_t",error_return);


    /*****************/
    /* Rho*U IS FINISHED */
    /*****************/



      /***********************/
      /* set up the Rho*V node */
      /***********************/

    sprintf(name,"MomentumY");
    ADF_Create(fsid,name,&newid,&error_return);     
    if(error_return > 0) err_exit("ADF_Create",error_return);
    oldid = newid;

      /* label Rho*V node */

    sprintf(label,"DataArray_t");
    ADF_Set_Label(oldid,label,&error_return);
    if(error_return > 0) err_exit("ADF_Set_Label:dataarray_t",error_return);

    dims = 3; /* a hardwire */
    dim_vals[0] = imax[iz];
    dim_vals[1] = jmax[iz];
    dim_vals[2] = kmax[iz];
    ADF_Put_Dimension_Information(oldid,"R4",dims,dim_vals,&error_return);     
    if(error_return > 0) err_exit("ADF_Put_Dimension_Information",error_return);

      /* write data for Rho*V */
    
    if( read(fin2,coord,(gridsize*sizeof(float))) != 
                       (gridsize*sizeof(float)))
      fatal("Error reading q.");

    s_start[0] = 1;  s_end[0] = imax[iz];  s_stride[0] = 1;
    s_start[1] = 1;  s_end[1] = jmax[iz];  s_stride[1] = 1;
    s_start[2] = 1;  s_end[2] = kmax[iz];  s_stride[2] = 1;
    m_num_dims = 3;
    m_dims[0] = imax[iz];
    m_dims[1] = jmax[iz];
    m_dims[2] = kmax[iz];
    m_start[0] = 1;  m_end[0] = imax[iz];  m_stride[0] = 1;
    m_start[1] = 1;  m_end[1] = jmax[iz];  m_stride[1] = 1;
    m_start[2] = 1;  m_end[2] = kmax[iz];  m_stride[2] = 1;

    ADF_Write_Data(oldid, s_start, s_end, s_stride,
                          m_num_dims, m_dims, 
                          m_start, m_end, m_stride, 
                          (char *)coord, &error_return);
    if(error_return > 0) err_exit("ADF_Write_Data",error_return);
/*
*/

      /* set up the units for the Rho*V node */

    sprintf(name,"DataUnits");
    ADF_Create(oldid,name,&newid,&error_return);     
    if(error_return > 0) err_exit("ADF_Create",error_return);
    oldid = newid;

      /* label dataunits node */

    sprintf(label,"DataUnits");
    ADF_Set_Label(oldid,label,&error_return);
    if(error_return > 0) err_exit("ADF_Set_Label:dataunits_t",error_return);


    /*****************/
    /* Rho*V IS FINISHED */
    /*****************/



      /***********************/
      /* set up the Rho*W node */
      /***********************/

    sprintf(name,"MomentumZ");
    ADF_Create(fsid,name,&newid,&error_return);     
    if(error_return > 0) err_exit("ADF_Create",error_return);
    oldid = newid;

      /* label Rho*W node */

    sprintf(label,"DataArray_t");
    ADF_Set_Label(oldid,label,&error_return);
    if(error_return > 0) err_exit("ADF_Set_Label:dataarray_t",error_return);

    dims = 3; /* a hardwire */
    dim_vals[0] = imax[iz];
    dim_vals[1] = jmax[iz];
    dim_vals[2] = kmax[iz];
    ADF_Put_Dimension_Information(oldid,"R4",dims,dim_vals,&error_return);     
    if(error_return > 0) err_exit("ADF_Put_Dimension_Information",error_return);

      /* write data for Rho*W */
    
    if( read(fin2,coord,(gridsize*sizeof(float))) != 
                       (gridsize*sizeof(float)))
      fatal("Error reading grid.");

    s_start[0] = 1;  s_end[0] = imax[iz];  s_stride[0] = 1;
    s_start[1] = 1;  s_end[1] = jmax[iz];  s_stride[1] = 1;
    s_start[2] = 1;  s_end[2] = kmax[iz];  s_stride[2] = 1;
    m_num_dims = 3;
    m_dims[0] = imax[iz];
    m_dims[1] = jmax[iz];
    m_dims[2] = kmax[iz];
    m_start[0] = 1;  m_end[0] = imax[iz];  m_stride[0] = 1;
    m_start[1] = 1;  m_end[1] = jmax[iz];  m_stride[1] = 1;
    m_start[2] = 1;  m_end[2] = kmax[iz];  m_stride[2] = 1;

    ADF_Write_Data(oldid, s_start, s_end, s_stride,
                          m_num_dims, m_dims, 
                          m_start, m_end, m_stride, 
                          (char *)coord, &error_return);
    if(error_return > 0) err_exit("ADF_Write_Data",error_return);
/*
*/

      /* set up the units for the Rho*W node */

    sprintf(name,"DataUnits");
    ADF_Create(oldid,name,&newid,&error_return);     
    if(error_return > 0) err_exit("ADF_Create",error_return);
    oldid = newid;

      /* label dataunits node */

    sprintf(label,"DataUnits");
    ADF_Set_Label(oldid,label,&error_return);
    if(error_return > 0) err_exit("ADF_Set_Label:dataunits_t",error_return);


    /*****************/
    /* Rho*W IS FINISHED */
    /*****************/



      /***********************/
      /* set up the E node */
      /***********************/

    sprintf(name,"EnergyStatic");
    ADF_Create(fsid,name,&newid,&error_return);     
    if(error_return > 0) err_exit("ADF_Create",error_return);
    oldid = newid;

      /* label E node */

    sprintf(label,"DataArray_t");
    ADF_Set_Label(oldid,label,&error_return);
    if(error_return > 0) err_exit("ADF_Set_Label:dataarray_t",error_return);

    dims = 3; /* a hardwire */
    dim_vals[0] = imax[iz];
    dim_vals[1] = jmax[iz];
    dim_vals[2] = kmax[iz];
    ADF_Put_Dimension_Information(oldid,"R4",dims,dim_vals,&error_return);     
    if(error_return > 0) err_exit("ADF_Put_Dimension_Information",error_return);

      /* write data for E */
    
    if( read(fin2,coord,(gridsize*sizeof(float))) != 
                       (gridsize*sizeof(float)))
      fatal("Error reading q.");

    s_start[0] = 1;  s_end[0] = imax[iz];  s_stride[0] = 1;
    s_start[1] = 1;  s_end[1] = jmax[iz];  s_stride[1] = 1;
    s_start[2] = 1;  s_end[2] = kmax[iz];  s_stride[2] = 1;
    m_num_dims = 3;
    m_dims[0] = imax[iz];
    m_dims[1] = jmax[iz];
    m_dims[2] = kmax[iz];
    m_start[0] = 1;  m_end[0] = imax[iz];  m_stride[0] = 1;
    m_start[1] = 1;  m_end[1] = jmax[iz];  m_stride[1] = 1;
    m_start[2] = 1;  m_end[2] = kmax[iz];  m_stride[2] = 1;

    ADF_Write_Data(oldid, s_start, s_end, s_stride,
                          m_num_dims, m_dims, 
                          m_start, m_end, m_stride, 
                          (char *)coord, &error_return);
    if(error_return > 0) err_exit("ADF_Write_Data",error_return);
/*
*/

      /* set up the units for the E node */

    sprintf(name,"DataUnits");
    ADF_Create(oldid,name,&newid,&error_return);     
    if(error_return > 0) err_exit("ADF_Create",error_return);
    oldid = newid;

      /* label dataunits node */

    sprintf(label,"DataUnits");
    ADF_Set_Label(oldid,label,&error_return);
    if(error_return > 0) err_exit("ADF_Set_Label:dataunits_t",error_return);


    /*****************/
    /* E IS FINISHED */
    /*****************/

      /* free up space for data */

    free(coord);


    printf("Finished with block %d of %d\n",iz+1,ng);
  }
  printf("\n");
}

void fatal(char *msg)
{
  printf("%s\n",msg);
  exit(1);
}
/*******************************************************************
    adf_to_p3d:
********************************************************************/
void adf_to_p3d()
{

    /* Prompt for input files */

  printf("Input the ADF filename > ");
  gets(filename);
  open_and_read_adf_headers(filename);

    /* plot3d output wired for 3D, binary, noblank, multigrid */

  printf("Input the plot3d grid filename (CR for none) > ");
  gets(filename);
  if(strlen(filename) != 0)
  {
    unlink(filename);
    open_and_write_p3dx(filename);
  }

  printf("Input the plot3d field filename (CR for none) > ");
  gets(filename);
  if(strlen(filename) != 0)
  {
    unlink(filename);
    open_and_write_p3dq(filename);
  }
}
/*******************************************************************/
void open_and_read_adf_headers(char *filename)
{
  int i, ic, iz;
  double zoneid, newid, oldid;
  char name[33], label[33];
  int error_return;
  int nlen;
  int dims, dim_vals[MAX_DIMENSIONS];

    /* Open the database */

  sprintf(status,"OLD");
  sprintf(format,"NATIVE");
  ADF_Database_Open(filename, status, format, &root_id, &error_return);
  if(error_return > 0) err_exit("ADF_Database_Open",error_return);

    /* Set to base node */
  
  sprintf(name,"Base1"); /* A hardwire, need to check and prompt for base */
  ADF_Get_Node_ID(root_id,name,&baseid,&error_return);
  if(error_return > 0) err_exit("ADF_Get_Node_ID",error_return);

    /* Read problem dimension */

  ADF_Read_All_Data(baseid, (char *)(&problemdimension), &error_return);
  if(error_return > 0) err_exit("ADF_Read_Data",error_return);
  if(problemdimension !=3) fatal("Can only Handle 3D");

    /* Loop over all the children counting Zone_t as a grid for output */

  ng = 0;
  ADF_Number_of_Children(baseid,&nchildren,&error_return);
  if(error_return > 0) err_exit("ADF_Number_of_Children",error_return);
  for(ic=1; ic<=nchildren; ic++)
  {
    ADF_Children_Names(baseid,ic,1,33,&nlen,name,&error_return);
    if(error_return > 0) err_exit("ADF_Childrens_Names",error_return);
    ADF_Get_Node_ID(baseid,name,&zoneid,&error_return);
    if(error_return > 0) err_exit("ADF_Get_Node_ID",error_return);
    ADF_Get_Label(zoneid,label,&error_return);     
    if(error_return > 0) err_exit("ADF_Get_Label",error_return);
    if ( strcmp(label,Zone_t) == 0 ) ng++ ;
  }
  if (ng == 0) fatal("No zone tags under current base");

    /* allocate space for the dimension arrays. */

  imax = (int *)malloc((unsigned)(ng*sizeof(int)));
  jmax = (int *)malloc((unsigned)(ng*sizeof(int)));
  kmax = (int *)malloc((unsigned)(ng*sizeof(int)));
  if ( imax == NULL || jmax == NULL || kmax == NULL )
     fatal("Error allocating memory");

   /* Load the arrays for writing to the plot3d headers */

  iz = 0;
  for(ic=1; ic<=nchildren; ic++)
  {
    ADF_Children_Names(baseid,ic,1,33,&nlen,name,&error_return);
    if(error_return > 0) err_exit("ADF_Childrens_Names",error_return);
    ADF_Get_Node_ID(baseid,name,&zoneid,&error_return);
    if(error_return > 0) err_exit("ADF_Get_Node_ID",error_return);
    ADF_Get_Label(zoneid,label,&error_return);     
    if(error_return > 0) err_exit("ADF_Get_Label",error_return);
    if ( strcmp(label,Zone_t) == 0 )
    {

       /* Get the dimensions in the zone node, currently we must read
          all the way down to a variable to get the zone dimension. */

      sprintf(name,"GridCoordinates");
      ADF_Get_Node_ID(zoneid,name,&newid,&error_return);
      if(error_return > 0) err_exit("ADF_Get_Node_ID",error_return);
      oldid = newid;
      sprintf(name,"X");
      ADF_Get_Node_ID(oldid,name,&newid,&error_return);
      if(error_return > 0) err_exit("ADF_Get_Node_ID",error_return);
      oldid = newid;
      ADF_Get_Dimension_Values(oldid,dim_vals,&error_return);
      if(error_return > 0) err_exit("ADF_Get_Dimension_Values",error_return);

      /* Save the dimensions, we assume that the node order wiil be the same
         later when we read the zone grid and solution, if not the we must
         save the zone names in a list !!! */

      imax[iz] = dim_vals[0] ;
      jmax[iz] = dim_vals[1] ;
      kmax[iz] = dim_vals[2] ;
      iz++;
    }
  }
}
/*******************************************************************/
void open_and_write_p3dx(char *filename)
{
  int i, iz, ic, gridsize, nlen;
  int fin;
  double zoneid, oldid, newid;
  float *coord;
  char name[33], label[33];
  int error_return;

     /* Open the file */

  fin = creat(filename,PERMS);
  if (fin <= 0)
  {
    printf("\nCOULD NOT OPEN plot3d FILE NAMED %s\n",filename);
    exit(1);
  }
   
     /* For multigrid we must write the number of zones. Hardwire to mg */

  if( write(fin,&ng,(sizeof(int))) != (sizeof(int)))
    fatal("Error writing ng.");

     /* Loop over and write the zone dimension data */
   
  for(i=0; i<ng; i++)
  {
    if( write(fin,&imax[i],(sizeof(int))) != (sizeof(int)))
    {
      sprintf(scratch,"Error writing imax[%d].",i);
      fatal(scratch);
    }
    if( write(fin,&jmax[i],(sizeof(int))) != (sizeof(int)))
    {
      sprintf(scratch,"Error writing jmax[%d].",i);
      fatal(scratch);
    }
    if( write(fin,&kmax[i],(sizeof(int))) != (sizeof(int)))
    {
      sprintf(scratch,"Error writing kmax[%d].",i);
      fatal(scratch);
    }

      /* Now lets write the grid for each zone */

  iz = 0 ;
  for(ic=1; ic<=nchildren; ic++)
  {
    ADF_Children_Names(baseid,ic,1,33,&nlen,name,&error_return);
    if(error_return > 0) err_exit("ADF_Childrens_Names",error_return);
    ADF_Get_Node_ID(baseid,name,&zoneid,&error_return);
    if(error_return > 0) err_exit("ADF_Get_Node_ID",error_return);
    ADF_Get_Label(zoneid,label,&error_return);     
    if(error_return > 0) err_exit("ADF_Get_Label",error_return);
    if ( strcmp(label,Zone_t) == 0 )
    {

      iz++ ; /* increment zone counter */

        /* Set to grid coordinates node */

      sprintf(name,"GridCoordinates");
      ADF_Get_Node_ID(zoneid,name,&newid,&error_return);
      if(error_return > 0) err_exit("ADF_Get_Node_ID",error_return);
      oldid = newid ;

        /* Alocate memory to read coordinate data. Note that here
           would be the place to have the ability to read real data
           out of the adf file even though it may be stored double!! */

      gridsize = imax[iz-1] * jmax[iz-1] * kmax[iz-1];
      coord = (float *)malloc((unsigned)(gridsize*sizeof(float)));
      if ( coord == NULL ) fatal("Error allocating coord memory!");

        /* write data for X */
    
      sprintf(name,"X");
      ADF_Get_Node_ID(oldid,name,&newid,&error_return);
      if(error_return > 0) err_exit("ADF_Get_Node_ID",error_return);
      ADF_Get_Data_Type(newid,name,&error_return);
      if(error_return > 0) err_exit("ADF_Get_Data_Type",error_return);
      if ( strncmp(name,"R4",2) != 0 ) fatal("Only real data supported");
      ADF_Read_All_Data(newid, (char *)coord, &error_return);
      if(error_return > 0) err_exit("ADF_Read_All_Data",error_return);

      if( write(fin,coord,(gridsize*sizeof(float))) != 
                          (gridsize*sizeof(float)))
      fatal("Error writing grid.");

        /* write data for Y */
    
      sprintf(name,"Y");
      ADF_Get_Node_ID(oldid,name,&newid,&error_return);
      if(error_return > 0) err_exit("ADF_Get_Node_ID",error_return);
      ADF_Get_Data_Type(newid,name,&error_return);
      if(error_return > 0) err_exit("ADF_Get_Data_Type",error_return);
      if ( strncmp(name,"R4",2) != 0 ) fatal("Only real data supported");
      ADF_Read_All_Data(newid, (char *)coord, &error_return);
      if(error_return > 0) err_exit("ADF_Read_All_Data",error_return);

      if( write(fin,coord,(gridsize*sizeof(float))) != 
                          (gridsize*sizeof(float)))
      fatal("Error writing grid.");

        /* write data for Z */
    
      sprintf(name,"Z");
      ADF_Get_Node_ID(oldid,name,&newid,&error_return);
      if(error_return > 0) err_exit("ADF_Get_Node_ID",error_return);
      ADF_Get_Data_Type(newid,name,&error_return);
      if(error_return > 0) err_exit("ADF_Get_Data_Type",error_return);
      if ( strncmp(name,"R4",2) != 0 ) fatal("Only real data supported");
      ADF_Read_All_Data(newid, (char *)coord, &error_return);
      if(error_return > 0) err_exit("ADF_Read_All_Data",error_return);

      if( write(fin,coord,(gridsize*sizeof(float))) != 
                          (gridsize*sizeof(float)))
      fatal("Error writing grid.");

      /* free up space for data */

    free(coord);

    printf("Finished with grid block %d of %d\n",iz,ng);
    }
  }

  }
}
/*******************************************************************/
void open_and_write_p3dq(char *filename)
{
  int i, iz, ic, flowsize, nlen;
  int fin;
  double zoneid, oldid, newid;
  float *flow;
  float fourfloats[4];
  char name[33], label[33];
  int error_return;

  fin = creat(filename,PERMS);
  if (fin <= 0)
  {
    printf("\nCOULD NOT OPEN plot3d q FILE NAMED %s\n",filename);
    exit(1);
  }
   
  if( write(fin,&ng,(sizeof(int))) != (sizeof(int)))
    fatal("Error writing ng.");
   
  for(i=0; i<ng; i++)
  {
    if( write(fin,&imax[i],(sizeof(int))) != (sizeof(int)))
    {
      sprintf(scratch,"Error writing imax[%d].",i);
      fatal(scratch);
    }
    if( write(fin,&jmax[i],(sizeof(int))) != (sizeof(int)))
    {
      sprintf(scratch,"Error writing jmax[%d].",i);
      fatal(scratch);
    }
    if( write(fin,&kmax[i],(sizeof(int))) != (sizeof(int)))
    {
      sprintf(scratch,"Error writing kmax[%d].",i);
      fatal(scratch);
    }

      /* Now lets write the solution */

  }
  iz = 0 ;
  for(ic=1; ic<=nchildren; ic++)
  {
    ADF_Children_Names(baseid,ic,1,33,&nlen,name,&error_return);
    if(error_return > 0) err_exit("ADF_Childrens_Names",error_return);
    ADF_Get_Node_ID(baseid,name,&zoneid,&error_return);
    if(error_return > 0) err_exit("ADF_Get_Node_ID",error_return);
    ADF_Get_Label(zoneid,label,&error_return);     
    if(error_return > 0) err_exit("ADF_Get_Label",error_return);
    if ( strcmp(label,Zone_t) == 0 )
    {

      iz++ ; /* increment zone counter */

        /* write four floats, we have not yet implemented the reference
           conditions so tata data is not available to save here!
           these four floats are usually FSMACH, ALPHA, RE, TIME */
    
      if( write(fin,fourfloats,(4*sizeof(float))) != 
                               (4*sizeof(float)))
      fatal("Error writing fourfloats.");

        /* Set to flow solution node */

      sprintf(name,"FlowSolution");
      ADF_Get_Node_ID(zoneid,name,&newid,&error_return);
      if(error_return > 0) err_exit("ADF_Get_Node_ID",error_return);
      oldid = newid ;

        /* Alocate memory to read flow data. Note that here
           would be the place to have the ability to read real data
           out of the adf file even though it may be stored double!! */

      flowsize = imax[iz-1] * jmax[iz-1] * kmax[iz-1];
      flow = (float *)malloc((unsigned)(flowsize*sizeof(float)));
      if ( flow == NULL ) fatal("Error allocating flow memory!");

        /* write data for RHO */
    
      sprintf(name,"DensityStatic");
      ADF_Get_Node_ID(oldid,name,&newid,&error_return);
      if(error_return > 0) err_exit("ADF_Get_Node_ID",error_return);
      ADF_Get_Data_Type(newid,name,&error_return);
      if(error_return > 0) err_exit("ADF_Get_Data_Type",error_return);
      if ( strncmp(name,"R4",2) != 0 ) fatal("Only real data supported");
      ADF_Read_All_Data(newid, (char *)flow, &error_return);
      if(error_return > 0) err_exit("ADF_Read_All_Data",error_return);

      if( write(fin,flow,(flowsize*sizeof(float))) != 
                          (flowsize*sizeof(float)))
      fatal("Error writing solution var RHO.");

        /* write data for RHO*U */
    
      sprintf(name,"MomentumX");
      ADF_Get_Node_ID(oldid,name,&newid,&error_return);
      if(error_return > 0) err_exit("ADF_Get_Node_ID",error_return);
      ADF_Get_Data_Type(newid,name,&error_return);
      if(error_return > 0) err_exit("ADF_Get_Data_Type",error_return);
      if ( strncmp(name,"R4",2) != 0 ) fatal("Only real data supported");
      ADF_Read_All_Data(newid, (char *)flow, &error_return);
      if(error_return > 0) err_exit("ADF_Read_All_Data",error_return);

      if( write(fin,flow,(flowsize*sizeof(float))) != 
                          (flowsize*sizeof(float)))
      fatal("Error writing solution var RHO*U.");

        /* write data for RHO*V */
    
      sprintf(name,"MomentumY");
      ADF_Get_Node_ID(oldid,name,&newid,&error_return);
      if(error_return > 0) err_exit("ADF_Get_Node_ID",error_return);
      ADF_Get_Data_Type(newid,name,&error_return);
      if(error_return > 0) err_exit("ADF_Get_Data_Type",error_return);
      if ( strncmp(name,"R4",2) != 0 ) fatal("Only real data supported");
      ADF_Read_All_Data(newid, (char *)flow, &error_return);
      if(error_return > 0) err_exit("ADF_Read_All_Data",error_return);

      if( write(fin,flow,(flowsize*sizeof(float))) != 
                          (flowsize*sizeof(float)))
      fatal("Error writing solution var RHO*V.");

        /* write data for RHO*W */
    
      sprintf(name,"MomentumZ");
      ADF_Get_Node_ID(oldid,name,&newid,&error_return);
      if(error_return > 0) err_exit("ADF_Get_Node_ID",error_return);
      ADF_Get_Data_Type(newid,name,&error_return);
      if(error_return > 0) err_exit("ADF_Get_Data_Type",error_return);
      if ( strncmp(name,"R4",2) != 0 ) fatal("Only real data supported");
      ADF_Read_All_Data(newid, (char *)flow, &error_return);
      if(error_return > 0) err_exit("ADF_Read_All_Data",error_return);

      if( write(fin,flow,(flowsize*sizeof(float))) != 
                          (flowsize*sizeof(float)))
      fatal("Error writing solution var RHO*Z.");

        /* write data for RHO*E0 */
    
      sprintf(name,"EnergyStatic");
      ADF_Get_Node_ID(oldid,name,&newid,&error_return);
      if(error_return > 0) err_exit("ADF_Get_Node_ID",error_return);
      ADF_Get_Data_Type(newid,name,&error_return);
      if(error_return > 0) err_exit("ADF_Get_Data_Type",error_return);
      if ( strncmp(name,"R4",2) != 0 ) fatal("Only real data supported");
      ADF_Read_All_Data(newid, (char *)flow, &error_return);
      if(error_return > 0) err_exit("ADF_Read_All_Data",error_return);

      if( write(fin,flow,(flowsize*sizeof(float))) != 
                          (flowsize*sizeof(float)))
      fatal("Error writing solution var RHO*E0.");
    }

      /* free up space for data */

    free(flow);

    printf("Finished with solution block %d of %d\n",iz,ng);
  }
}
